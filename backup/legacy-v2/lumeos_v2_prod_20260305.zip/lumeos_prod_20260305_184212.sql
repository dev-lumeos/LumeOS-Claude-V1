


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


COMMENT ON SCHEMA "public" IS 'standard public schema';



CREATE EXTENSION IF NOT EXISTS "pg_graphql" WITH SCHEMA "graphql";






CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "pg_trgm" WITH SCHEMA "public";






CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";






CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";






CREATE OR REPLACE FUNCTION "public"."update_updated_at_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_updated_at_column"() OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";


CREATE TABLE IF NOT EXISTS "public"."agent_log" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "task_id" "uuid",
    "agent" "text" NOT NULL,
    "action" "text" NOT NULL,
    "details" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."agent_log" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."agent_tasks" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "title" "text" NOT NULL,
    "status" "text" DEFAULT 'pending'::"text" NOT NULL,
    "priority" integer DEFAULT 50,
    "agent" "text",
    "module" "text",
    "spec_ref" "text",
    "task_prompt" "text",
    "result" "text",
    "changed_files" "text"[],
    "error" "text",
    "created_by" "text" DEFAULT 'jarvis'::"text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "started_at" timestamp with time zone,
    "completed_at" timestamp with time zone,
    "updated_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "agent_tasks_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'working'::"text", 'done'::"text", 'blocked'::"text", 'failed'::"text", 'cancelled'::"text"])))
);


ALTER TABLE "public"."agent_tasks" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."agent_tasks_active" AS
 SELECT "id",
    "title",
    "status",
    "priority",
    "agent",
    "module",
    "created_at",
    "started_at",
    (EXTRACT(epoch FROM ("now"() - "started_at")) / (60)::numeric) AS "minutes_running"
   FROM "public"."agent_tasks"
  WHERE ("status" = ANY (ARRAY['pending'::"text", 'working'::"text", 'blocked'::"text"]))
  ORDER BY "priority", "created_at";


ALTER VIEW "public"."agent_tasks_active" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."agent_tasks_recent" AS
 SELECT "id",
    "title",
    "status",
    "agent",
    "module",
    "created_at",
    "completed_at",
    "array_length"("changed_files", 1) AS "files_changed",
    ( SELECT "count"(*) AS "count"
           FROM "public"."agent_log" "l"
          WHERE ("l"."task_id" = "t"."id")) AS "log_entries"
   FROM "public"."agent_tasks" "t"
  ORDER BY "updated_at" DESC
 LIMIT 50;


ALTER VIEW "public"."agent_tasks_recent" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."auto_adjust_rules" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "goal_id" "uuid" NOT NULL,
    "is_active" boolean DEFAULT false,
    "check_interval_days" integer DEFAULT 14,
    "min_data_points" integer DEFAULT 7,
    "weight_stall_threshold_kg" numeric(3,1) DEFAULT 0.2,
    "calorie_adjustment_step" integer DEFAULT 100,
    "min_calories" integer DEFAULT 1200,
    "max_calories" integer DEFAULT 5000,
    "last_check_at" timestamp with time zone,
    "last_adjustment_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."auto_adjust_rules" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."biomarkers" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "loinc_code" "text",
    "name" "text" NOT NULL,
    "name_de" "text" NOT NULL,
    "category" "text" NOT NULL,
    "unit" "text" NOT NULL,
    "lab_range_min" numeric(10,4),
    "lab_range_max" numeric(10,4),
    "optimal_range_min" numeric(10,4),
    "optimal_range_max" numeric(10,4),
    "description" "text",
    "description_de" "text",
    "relevance" "text"[],
    "sort_order" integer DEFAULT 0
);


ALTER TABLE "public"."biomarkers" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."body_circumferences" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "date" "date" NOT NULL,
    "neck_cm" numeric(4,1),
    "shoulders_cm" numeric(5,1),
    "chest_cm" numeric(5,1),
    "upper_arm_left_cm" numeric(4,1),
    "upper_arm_right_cm" numeric(4,1),
    "forearm_left_cm" numeric(4,1),
    "forearm_right_cm" numeric(4,1),
    "waist_cm" numeric(5,1),
    "hip_cm" numeric(5,1),
    "thigh_left_cm" numeric(4,1),
    "thigh_right_cm" numeric(4,1),
    "calf_left_cm" numeric(4,1),
    "calf_right_cm" numeric(4,1),
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."body_circumferences" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."body_goals" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "goal_type" character varying(20) NOT NULL,
    "target_metric" character varying(30),
    "target_value" numeric(6,2) NOT NULL,
    "current_value" numeric(6,2),
    "deadline" "date",
    "status" character varying(10) DEFAULT 'active'::character varying,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."body_goals" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."body_measurements" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "date" "date" NOT NULL,
    "weight_kg" numeric(5,2),
    "body_fat_pct" numeric(4,1),
    "method" character varying(20) DEFAULT 'visual'::character varying,
    "muscle_mass_kg" numeric(5,2),
    "bmi" numeric(4,1),
    "ffmi" numeric(4,1),
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."body_measurements" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."body_photos" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "session_id" "uuid",
    "pose_type" character varying(30) NOT NULL,
    "image_path" character varying(500),
    "thumbnail_path" character varying(500),
    "ai_analysis" "jsonb",
    "ai_scores" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."body_photos" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."checkin_analysis" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "checkin_id" "uuid" NOT NULL,
    "coach_id" "uuid" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "nutrition_score" integer,
    "nutrition_avg_calories" numeric,
    "nutrition_avg_protein" numeric,
    "nutrition_avg_carbs" numeric,
    "nutrition_avg_fat" numeric,
    "nutrition_compliance" integer,
    "supplement_score" integer,
    "supplement_compliance" integer,
    "supplement_streak" integer,
    "training_score" integer,
    "training_sessions" integer,
    "training_volume" numeric,
    "recovery_score" integer,
    "recovery_avg_sleep" numeric,
    "recovery_avg_stress" numeric,
    "recovery_avg_energy" numeric,
    "goal_progress" "jsonb",
    "insights" "jsonb" DEFAULT '[]'::"jsonb",
    "recommendations" "jsonb" DEFAULT '[]'::"jsonb",
    "flags" "jsonb" DEFAULT '[]'::"jsonb",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."checkin_analysis" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coach_action_log" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "action_type" "text" NOT NULL,
    "action_data" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "undo_data" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "undone_at" timestamp with time zone
);


ALTER TABLE "public"."coach_action_log" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coach_ai_actions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "coach_id" "uuid" NOT NULL,
    "action_type" "text" NOT NULL,
    "description" "text" NOT NULL,
    "client_id" "uuid",
    "input" "jsonb" DEFAULT '{}'::"jsonb",
    "output" "jsonb" DEFAULT '{}'::"jsonb",
    "result_ref" "jsonb" DEFAULT '{}'::"jsonb",
    "status" "text" DEFAULT 'completed'::"text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "coach_ai_actions_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'completed'::"text", 'failed'::"text", 'cancelled'::"text"])))
);


ALTER TABLE "public"."coach_ai_actions" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coach_ai_automations" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "coach_id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "description" "text",
    "trigger_type" "text" NOT NULL,
    "conditions" "jsonb" DEFAULT '{}'::"jsonb",
    "action_type" "text" NOT NULL,
    "action_config" "jsonb" DEFAULT '{}'::"jsonb",
    "is_active" boolean DEFAULT true,
    "run_count" integer DEFAULT 0,
    "last_run_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "coach_ai_automations_action_type_check" CHECK (("action_type" = ANY (ARRAY['send_message'::"text", 'create_alert'::"text", 'update_checkin'::"text", 'log_memory'::"text", 'draft_message'::"text", 'notify_coach'::"text"]))),
    CONSTRAINT "coach_ai_automations_trigger_type_check" CHECK (("trigger_type" = ANY (ARRAY['message_received'::"text", 'checkin_submitted'::"text", 'alert_created'::"text", 'plan_accepted'::"text", 'plan_rejected'::"text", 'scheduled'::"text", 'compliance_drop'::"text", 'manual'::"text"])))
);


ALTER TABLE "public"."coach_ai_automations" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coach_ai_memory" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "coach_id" "uuid" NOT NULL,
    "category" "text" NOT NULL,
    "key" "text" NOT NULL,
    "content" "text" NOT NULL,
    "client_id" "uuid",
    "source" "text" DEFAULT 'coach'::"text",
    "is_active" boolean DEFAULT true,
    "priority" integer DEFAULT 0,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "coach_ai_memory_category_check" CHECK (("category" = ANY (ARRAY['preference'::"text", 'client_note'::"text", 'template_rule'::"text", 'auto_response'::"text", 'workflow'::"text", 'general'::"text"])))
);


ALTER TABLE "public"."coach_ai_memory" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coach_briefings" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "date" "date" DEFAULT CURRENT_DATE NOT NULL,
    "briefing_type" "text" NOT NULL,
    "content" "jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "coach_briefings_briefing_type_check" CHECK (("briefing_type" = ANY (ARRAY['morning'::"text", 'evening'::"text"])))
);


ALTER TABLE "public"."coach_briefings" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coach_checkins" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "coach_id" "uuid" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "week_number" integer,
    "auto_data" "jsonb" DEFAULT '{}'::"jsonb",
    "client_data" "jsonb" DEFAULT '{}'::"jsonb",
    "coach_notes" "text",
    "coach_feedback" "text",
    "action_items" "jsonb" DEFAULT '[]'::"jsonb",
    "status" "text" DEFAULT 'pending'::"text",
    "due_date" "date",
    "submitted_at" timestamp with time zone,
    "reviewed_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "coach_checkins_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'client_submitted'::"text", 'coach_reviewed'::"text", 'completed'::"text"])))
);


ALTER TABLE "public"."coach_checkins" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coach_client_alerts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "coach_id" "uuid" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "level" "text" NOT NULL,
    "category" "text" NOT NULL,
    "title" "text" NOT NULL,
    "message" "text" NOT NULL,
    "data" "jsonb" DEFAULT '{}'::"jsonb",
    "is_read" boolean DEFAULT false,
    "is_dismissed" boolean DEFAULT false,
    "created_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "coach_client_alerts_level_check" CHECK (("level" = ANY (ARRAY['critical'::"text", 'warning'::"text", 'info'::"text", 'success'::"text"])))
);


ALTER TABLE "public"."coach_client_alerts" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coach_client_messages" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "coach_id" "uuid" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "sender" "text" NOT NULL,
    "content" "text" NOT NULL,
    "message_type" "text" DEFAULT 'text'::"text",
    "media_url" "text",
    "metadata" "jsonb" DEFAULT '{}'::"jsonb",
    "is_read" boolean DEFAULT false,
    "created_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "coach_client_messages_message_type_check" CHECK (("message_type" = ANY (ARRAY['text'::"text", 'voice'::"text", 'video'::"text", 'image'::"text", 'file'::"text", 'checkin'::"text", 'program'::"text"]))),
    CONSTRAINT "coach_client_messages_sender_check" CHECK (("sender" = ANY (ARRAY['coach'::"text", 'client'::"text", 'system'::"text", 'ai_clone'::"text"])))
);


ALTER TABLE "public"."coach_client_messages" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coach_client_permissions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "coach_client_id" "uuid" NOT NULL,
    "coach_id" "uuid" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "read_nutrition" boolean DEFAULT false,
    "read_supplements" boolean DEFAULT false,
    "read_training" boolean DEFAULT false,
    "read_recovery" boolean DEFAULT false,
    "read_goals" boolean DEFAULT false,
    "read_medical" boolean DEFAULT false,
    "read_body_composition" boolean DEFAULT false,
    "write_training_plans" boolean DEFAULT false,
    "write_nutrition_plans" boolean DEFAULT false,
    "write_supplement_plans" boolean DEFAULT false,
    "edit_auto_accept" boolean DEFAULT false,
    "edit_goals" boolean DEFAULT false,
    "medical_consent_given" boolean DEFAULT false,
    "medical_consent_date" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."coach_client_permissions" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coach_clients" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "coach_id" "uuid" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "client_name" "text",
    "client_email" "text",
    "status" "text" DEFAULT 'active'::"text",
    "permissions" "jsonb" DEFAULT '{"goals": "full", "medical": "none", "recovery": "summary", "training": "full", "nutrition": "full", "bodyMetrics": "summary", "supplements": "summary"}'::"jsonb" NOT NULL,
    "tags" "text"[] DEFAULT '{}'::"text"[],
    "goal" "text",
    "notes" "text",
    "monthly_fee" numeric(10,2),
    "started_at" timestamp with time zone DEFAULT "now"(),
    "expires_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "coach_clients_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'active'::"text", 'paused'::"text", 'ended'::"text"])))
);


ALTER TABLE "public"."coach_clients" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coach_conversation_summaries" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "conversation_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "summary" "text" NOT NULL,
    "topics" "text"[] DEFAULT '{}'::"text"[],
    "key_facts" "text"[] DEFAULT '{}'::"text"[],
    "message_count" integer DEFAULT 0,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."coach_conversation_summaries" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coach_conversations" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "title" "text",
    "persona" "text" DEFAULT 'best_friend'::"text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "coach_conversations_persona_check" CHECK (("persona" = ANY (ARRAY['scientist'::"text", 'motivator'::"text", 'drill_sergeant'::"text", 'best_friend'::"text", 'sensei'::"text"])))
);


ALTER TABLE "public"."coach_conversations" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coach_memory" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "category" "text" NOT NULL,
    "key" "text" NOT NULL,
    "value" "text" NOT NULL,
    "source" "text" DEFAULT 'chat'::"text",
    "confidence" real DEFAULT 0.8,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."coach_memory" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coach_messages" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "conversation_id" "uuid" NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "role" "text" NOT NULL,
    "content" "text" NOT NULL,
    "context_snapshot" "jsonb" DEFAULT '{}'::"jsonb",
    "tokens_used" integer DEFAULT 0,
    "model" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "coach_messages_role_check" CHECK (("role" = ANY (ARRAY['user'::"text", 'assistant'::"text", 'system'::"text"])))
);


ALTER TABLE "public"."coach_messages" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coach_pending_actions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "conversation_id" "uuid",
    "action_type" "text" NOT NULL,
    "action_data" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "preview_data" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone DEFAULT ("now"() + '00:10:00'::interval) NOT NULL,
    "confirmed_at" timestamp with time zone
);


ALTER TABLE "public"."coach_pending_actions" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coach_plan_assignments" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "template_id" "uuid" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "coach_id" "uuid" NOT NULL,
    "status" "text" DEFAULT 'pending'::"text" NOT NULL,
    "start_date" "date",
    "customizations" "jsonb" DEFAULT '{}'::"jsonb",
    "coach_notes" "text",
    "imported_at" timestamp with time zone,
    "imported_refs" "jsonb" DEFAULT '{}'::"jsonb",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "coach_plan_assignments_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'accepted'::"text", 'active'::"text", 'rejected'::"text", 'completed'::"text", 'cancelled'::"text"])))
);


ALTER TABLE "public"."coach_plan_assignments" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coach_plan_templates" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "coach_id" "uuid" NOT NULL,
    "type" "text" NOT NULL,
    "name" "text" NOT NULL,
    "description" "text",
    "tags" "text"[] DEFAULT '{}'::"text"[],
    "difficulty" "text",
    "duration_weeks" integer,
    "target_profile" "jsonb" DEFAULT '{}'::"jsonb",
    "content" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "bundle_template_ids" "uuid"[] DEFAULT '{}'::"uuid"[],
    "visibility" "text" DEFAULT 'private'::"text" NOT NULL,
    "price_credits" integer DEFAULT 0,
    "sales_count" integer DEFAULT 0,
    "avg_rating" numeric(3,2),
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "coach_plan_templates_difficulty_check" CHECK (("difficulty" = ANY (ARRAY['beginner'::"text", 'intermediate'::"text", 'advanced'::"text", 'elite'::"text"]))),
    CONSTRAINT "coach_plan_templates_type_check" CHECK (("type" = ANY (ARRAY['nutrition'::"text", 'supplement'::"text", 'cycle'::"text", 'training'::"text", 'bundle'::"text"]))),
    CONSTRAINT "coach_plan_templates_visibility_check" CHECK (("visibility" = ANY (ARRAY['private'::"text", 'clients'::"text", 'marketplace'::"text"])))
);


ALTER TABLE "public"."coach_plan_templates" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coach_programs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "coach_id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "description" "text",
    "type" "text" NOT NULL,
    "duration_weeks" integer,
    "difficulty" "text",
    "phases" "jsonb" DEFAULT '[]'::"jsonb",
    "templates" "jsonb" DEFAULT '{}'::"jsonb",
    "is_template" boolean DEFAULT false,
    "marketplace_listed" boolean DEFAULT false,
    "marketplace_price" numeric(10,2),
    "marketplace_description" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "coach_programs_difficulty_check" CHECK (("difficulty" = ANY (ARRAY['beginner'::"text", 'intermediate'::"text", 'advanced'::"text", 'elite'::"text"]))),
    CONSTRAINT "coach_programs_type_check" CHECK (("type" = ANY (ARRAY['training'::"text", 'nutrition'::"text", 'combined'::"text", 'supplement'::"text", 'full'::"text"])))
);


ALTER TABLE "public"."coach_programs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coach_settings" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "persona" "text" DEFAULT 'best_friend'::"text",
    "language" "text" DEFAULT 'de'::"text",
    "proactive_enabled" boolean DEFAULT true,
    "daily_briefing" boolean DEFAULT true,
    "insight_notifications" boolean DEFAULT true,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."coach_settings" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coach_weekly_reports" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "week_start" "date" NOT NULL,
    "week_end" "date" NOT NULL,
    "report" "jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."coach_weekly_reports" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."coaches" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "business_name" "text",
    "bio" "text",
    "specialties" "text"[] DEFAULT '{}'::"text"[],
    "certifications" "text"[] DEFAULT '{}'::"text"[],
    "tier" "text" DEFAULT 'starter'::"text",
    "branding" "jsonb" DEFAULT '{}'::"jsonb",
    "avatar_url" "text",
    "contact_email" "text",
    "website" "text",
    "social_links" "jsonb" DEFAULT '{}'::"jsonb",
    "max_clients" integer DEFAULT 10,
    "is_active" boolean DEFAULT true,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "coaches_tier_check" CHECK (("tier" = ANY (ARRAY['starter'::"text", 'professional'::"text", 'business'::"text", 'enterprise'::"text"])))
);


ALTER TABLE "public"."coaches" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."cycle_plans" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "name" "text" NOT NULL,
    "start_date" "date",
    "status" "text" DEFAULT 'planned'::"text",
    "compounds" "jsonb" NOT NULL,
    "pct" "jsonb",
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "source" "text" DEFAULT 'user'::"text",
    "source_template_id" "uuid",
    "coach_locked" boolean DEFAULT false,
    CONSTRAINT "cycle_plans_source_check" CHECK (("source" = ANY (ARRAY['user'::"text", 'coach'::"text", 'marketplace'::"text"])))
);


ALTER TABLE "public"."cycle_plans" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."meal_items" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "meal_id" "uuid" NOT NULL,
    "food_id" "uuid",
    "food_source" "text" DEFAULT 'bls'::"text" NOT NULL,
    "food_name" "text" NOT NULL,
    "amount_g" numeric(8,2) NOT NULL,
    "kcal" numeric(8,2),
    "protein_g" numeric(8,3),
    "fat_g" numeric(8,3),
    "carbs_g" numeric(8,3),
    "sugar_g" numeric(8,3),
    "fiber_g" numeric(8,3),
    "salt_g" numeric(8,3),
    "vitamin_a_ug" numeric(8,3),
    "vitamin_d_ug" numeric(8,3),
    "vitamin_e_mg" numeric(8,3),
    "vitamin_k_ug" numeric(8,3),
    "vitamin_c_mg" numeric(8,3),
    "thiamin_mg" numeric(8,3),
    "riboflavin_mg" numeric(8,3),
    "niacin_mg" numeric(8,3),
    "vitamin_b6_mg" numeric(8,3),
    "folate_ug" numeric(8,3),
    "vitamin_b12_ug" numeric(8,3),
    "pantothenic_acid_mg" numeric(8,3),
    "biotin_ug" numeric(8,3),
    "calcium_mg" numeric(8,3),
    "iron_mg" numeric(8,3),
    "magnesium_mg" numeric(8,3),
    "phosphorus_mg" numeric(8,3),
    "potassium_mg" numeric(8,3),
    "sodium_mg" numeric(8,3),
    "zinc_mg" numeric(8,3),
    "copper_mg" numeric(8,3),
    "manganese_mg" numeric(8,3),
    "selenium_ug" numeric(8,3),
    "iodine_ug" numeric(8,3),
    "cholesterol_mg" numeric(8,3),
    "fat_sat_g" numeric(8,3),
    "fat_mono_g" numeric(8,3),
    "fat_poly_g" numeric(8,3),
    "created_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "meal_items_food_source_check" CHECK (("food_source" = ANY (ARRAY['bls'::"text", 'custom'::"text", 'openfoodfacts'::"text", 'mealcam'::"text"])))
);


ALTER TABLE "public"."meal_items" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."meals" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "date" "date" NOT NULL,
    "meal_type" "text" NOT NULL,
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "meals_meal_type_check" CHECK (("meal_type" = ANY (ARRAY['breakfast'::"text", 'lunch'::"text", 'dinner'::"text", 'snack'::"text"])))
);


ALTER TABLE "public"."meals" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."water_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "date" "date" NOT NULL,
    "amount_ml" numeric(8,2) NOT NULL,
    "source" "text" DEFAULT 'manual'::"text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."water_logs" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."daily_nutrition_summary" AS
 SELECT "m"."user_id",
    "m"."date",
    "count"(DISTINCT "m"."id") AS "meal_count",
    COALESCE("sum"("mi"."kcal"), (0)::numeric) AS "total_kcal",
    COALESCE("sum"("mi"."protein_g"), (0)::numeric) AS "total_protein_g",
    COALESCE("sum"("mi"."fat_g"), (0)::numeric) AS "total_fat_g",
    COALESCE("sum"("mi"."carbs_g"), (0)::numeric) AS "total_carbs_g",
    COALESCE("sum"("mi"."sugar_g"), (0)::numeric) AS "total_sugar_g",
    COALESCE("sum"("mi"."fiber_g"), (0)::numeric) AS "total_fiber_g",
    COALESCE("sum"("mi"."salt_g"), (0)::numeric) AS "total_salt_g",
    COALESCE("sum"("mi"."vitamin_a_ug"), (0)::numeric) AS "total_vitamin_a_ug",
    COALESCE("sum"("mi"."vitamin_d_ug"), (0)::numeric) AS "total_vitamin_d_ug",
    COALESCE("sum"("mi"."vitamin_e_mg"), (0)::numeric) AS "total_vitamin_e_mg",
    COALESCE("sum"("mi"."vitamin_k_ug"), (0)::numeric) AS "total_vitamin_k_ug",
    COALESCE("sum"("mi"."vitamin_c_mg"), (0)::numeric) AS "total_vitamin_c_mg",
    COALESCE("sum"("mi"."thiamin_mg"), (0)::numeric) AS "total_thiamin_mg",
    COALESCE("sum"("mi"."riboflavin_mg"), (0)::numeric) AS "total_riboflavin_mg",
    COALESCE("sum"("mi"."niacin_mg"), (0)::numeric) AS "total_niacin_mg",
    COALESCE("sum"("mi"."vitamin_b6_mg"), (0)::numeric) AS "total_vitamin_b6_mg",
    COALESCE("sum"("mi"."folate_ug"), (0)::numeric) AS "total_folate_ug",
    COALESCE("sum"("mi"."vitamin_b12_ug"), (0)::numeric) AS "total_vitamin_b12_ug",
    COALESCE("sum"("mi"."calcium_mg"), (0)::numeric) AS "total_calcium_mg",
    COALESCE("sum"("mi"."iron_mg"), (0)::numeric) AS "total_iron_mg",
    COALESCE("sum"("mi"."magnesium_mg"), (0)::numeric) AS "total_magnesium_mg",
    COALESCE("sum"("mi"."phosphorus_mg"), (0)::numeric) AS "total_phosphorus_mg",
    COALESCE("sum"("mi"."potassium_mg"), (0)::numeric) AS "total_potassium_mg",
    COALESCE("sum"("mi"."sodium_mg"), (0)::numeric) AS "total_sodium_mg",
    COALESCE("sum"("mi"."zinc_mg"), (0)::numeric) AS "total_zinc_mg",
    COALESCE("sum"("mi"."selenium_ug"), (0)::numeric) AS "total_selenium_ug",
    COALESCE("sum"("mi"."iodine_ug"), (0)::numeric) AS "total_iodine_ug",
    COALESCE("sum"("mi"."cholesterol_mg"), (0)::numeric) AS "total_cholesterol_mg",
    COALESCE("sum"("mi"."fat_sat_g"), (0)::numeric) AS "total_fat_sat_g",
    COALESCE("sum"("mi"."fat_mono_g"), (0)::numeric) AS "total_fat_mono_g",
    COALESCE("sum"("mi"."fat_poly_g"), (0)::numeric) AS "total_fat_poly_g",
    ( SELECT COALESCE("sum"("wl"."amount_ml"), (0)::numeric) AS "coalesce"
           FROM "public"."water_logs" "wl"
          WHERE (("wl"."user_id" = "m"."user_id") AND ("wl"."date" = "m"."date"))) AS "total_water_ml"
   FROM ("public"."meals" "m"
     LEFT JOIN "public"."meal_items" "mi" ON (("mi"."meal_id" = "m"."id")))
  GROUP BY "m"."user_id", "m"."date";


ALTER VIEW "public"."daily_nutrition_summary" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."enhanced_substances" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "aliases" "text"[],
    "category" "text" NOT NULL,
    "half_life_hours" numeric,
    "active_life_hours" numeric,
    "detection_time_days" numeric,
    "route" "text",
    "typical_dose_min" numeric,
    "typical_dose_max" numeric,
    "dose_unit" "text",
    "frequency" "text",
    "monitoring_markers" "text"[],
    "warnings" "text"[],
    "legal_note" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."enhanced_substances" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."equipment" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "name_de" "text",
    "name_th" "text",
    "category" "text",
    "icon" "text"
);


ALTER TABLE "public"."equipment" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."exercise_muscles" (
    "exercise_id" "uuid" NOT NULL,
    "muscle_group_id" "uuid" NOT NULL,
    "role" "text" NOT NULL,
    CONSTRAINT "exercise_muscles_role_check" CHECK (("role" = ANY (ARRAY['primary'::"text", 'secondary'::"text"])))
);


ALTER TABLE "public"."exercise_muscles" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."exercise_progression_config" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "exercise_id" "uuid" NOT NULL,
    "progression_model" "text" DEFAULT 'double_progression'::"text" NOT NULL,
    "increment_kg" numeric(4,2) DEFAULT 2.5,
    "rep_range_min" integer DEFAULT 8,
    "rep_range_max" integer DEFAULT 12,
    "target_rpe" numeric(3,1),
    "wave_week" integer DEFAULT 1,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."exercise_progression_config" OWNER TO "postgres";


COMMENT ON TABLE "public"."exercise_progression_config" IS 'Per-exercise progression model configuration for training programs';



COMMENT ON COLUMN "public"."exercise_progression_config"."progression_model" IS 'linear, double_progression, wave_loading, rpe_based, or daily_undulating';



COMMENT ON COLUMN "public"."exercise_progression_config"."increment_kg" IS 'Weight increment for progression (default 2.5kg for lower, 1.25kg for upper)';



COMMENT ON COLUMN "public"."exercise_progression_config"."wave_week" IS 'Current week in wave_loading cycle (1-3)';



CREATE TABLE IF NOT EXISTS "public"."exercises" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "category" "text" NOT NULL,
    "primary_muscles" "text"[] NOT NULL,
    "secondary_muscles" "text"[] DEFAULT '{}'::"text"[],
    "equipment" "text" NOT NULL,
    "description" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "name_de" "text",
    "name_th" "text",
    "instructions" "text",
    "tips" "text",
    "equipment_id" "uuid",
    "exercise_type" "text" DEFAULT 'strength'::"text",
    "tracking_type" "text" DEFAULT 'weight_reps'::"text",
    "difficulty" "text" DEFAULT 'intermediate'::"text",
    "image_male_start" "text",
    "image_male_end" "text",
    "image_female_start" "text",
    "image_female_end" "text",
    "video_url" "text",
    "source" "text" DEFAULT 'manual'::"text",
    "is_custom" boolean DEFAULT false,
    "score_hypertrophy" smallint,
    "score_strength" smallint,
    "score_sfr" smallint,
    "common_mistakes" "text"[] DEFAULT '{}'::"text"[],
    "aliases" "text"[] DEFAULT '{}'::"text"[],
    CONSTRAINT "exercises_score_hypertrophy_check" CHECK ((("score_hypertrophy" >= 0) AND ("score_hypertrophy" <= 100))),
    CONSTRAINT "exercises_score_sfr_check" CHECK ((("score_sfr" >= 0) AND ("score_sfr" <= 100))),
    CONSTRAINT "exercises_score_strength_check" CHECK ((("score_strength" >= 0) AND ("score_strength" <= 100)))
);


ALTER TABLE "public"."exercises" OWNER TO "postgres";


COMMENT ON COLUMN "public"."exercises"."score_hypertrophy" IS 'Hypertrophy effectiveness 0-100 (stretch + tension + mind-muscle connection)';



COMMENT ON COLUMN "public"."exercises"."score_strength" IS 'Strength development effectiveness 0-100';



COMMENT ON COLUMN "public"."exercises"."score_sfr" IS 'Stimulus to Fatigue Ratio 0-100 (high = good stimulus, low fatigue)';



COMMENT ON COLUMN "public"."exercises"."common_mistakes" IS 'Array of common form mistakes';



COMMENT ON COLUMN "public"."exercises"."aliases" IS 'Searchable alternative names (e.g. Bench → Barbell Bench Press)';



CREATE TABLE IF NOT EXISTS "public"."food_favorites" (
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "food_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."food_favorites" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."foods" (
    "id" "uuid" NOT NULL,
    "bls_code" "text" NOT NULL,
    "name_de" "text" NOT NULL,
    "name_en" "text",
    "category" "text" NOT NULL,
    "category_code" "text" NOT NULL,
    "source" "text" DEFAULT 'bls_4.0'::"text" NOT NULL,
    "confidence" numeric(12,3) DEFAULT 1.0 NOT NULL,
    "kcal" numeric(12,3),
    "kj" numeric(12,3),
    "protein_g" numeric(12,3),
    "fat_g" numeric(12,3),
    "carbs_g" numeric(12,3),
    "sugar_g" numeric(12,3),
    "fiber_g" numeric(12,3),
    "salt_g" numeric(12,3),
    "water_g" numeric(12,3),
    "alcohol_g" numeric(12,3),
    "fat_mono_g" numeric(12,3),
    "fat_poly_g" numeric(12,3),
    "fat_sat_g" numeric(12,3),
    "cholesterol_mg" numeric(12,3),
    "calcium_mg" numeric(12,3),
    "iron_mg" numeric(12,3),
    "magnesium_mg" numeric(12,3),
    "phosphorus_mg" numeric(12,3),
    "potassium_mg" numeric(12,3),
    "sodium_mg" numeric(12,3),
    "zinc_mg" numeric(12,3),
    "copper_mg" numeric(12,3),
    "manganese_mg" numeric(12,3),
    "selenium_ug" numeric(12,3),
    "iodine_ug" numeric(12,3),
    "vitamin_a_ug" numeric(12,3),
    "vitamin_d_ug" numeric(12,3),
    "vitamin_e_mg" numeric(12,3),
    "vitamin_k_ug" numeric(12,3),
    "vitamin_c_mg" numeric(12,3),
    "thiamin_mg" numeric(12,3),
    "riboflavin_mg" numeric(12,3),
    "niacin_mg" numeric(12,3),
    "vitamin_b6_mg" numeric(12,3),
    "folate_ug" numeric(12,3),
    "vitamin_b12_ug" numeric(12,3),
    "pantothenic_acid_mg" numeric(12,3),
    "biotin_ug" numeric(12,3),
    "is_verified" boolean DEFAULT true,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "nutrients_full" "jsonb" DEFAULT '{}'::"jsonb",
    "allergens" "text"[] DEFAULT '{}'::"text"[]
);


ALTER TABLE "public"."foods" OWNER TO "postgres";


COMMENT ON TABLE "public"."foods" IS 'Lumeos Food-DB, initialisiert aus BLS 4.0';



COMMENT ON COLUMN "public"."foods"."nutrients_full" IS 'Complete BLS nutrient data (98 nutrients) as JSONB';



COMMENT ON COLUMN "public"."foods"."allergens" IS 'Standard allergens: gluten, dairy, eggs, nuts, peanuts, soy, fish, shellfish, sesame, celery, mustard, sulfites, lupin, molluscs';



CREATE TABLE IF NOT EXISTS "public"."foods_custom" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "name_de" "text" NOT NULL,
    "name_en" "text",
    "kcal" numeric(8,2),
    "protein_g" numeric(8,3),
    "fat_g" numeric(8,3),
    "carbs_g" numeric(8,3),
    "sugar_g" numeric(8,3),
    "fiber_g" numeric(8,3),
    "salt_g" numeric(8,3),
    "vitamin_a_ug" numeric(8,3),
    "vitamin_c_mg" numeric(8,3),
    "vitamin_d_ug" numeric(8,3),
    "calcium_mg" numeric(8,3),
    "iron_mg" numeric(8,3),
    "magnesium_mg" numeric(8,3),
    "potassium_mg" numeric(8,3),
    "sodium_mg" numeric(8,3),
    "zinc_mg" numeric(8,3),
    "barcode" "text",
    "source" "text" DEFAULT 'user'::"text",
    "confidence" numeric(3,2) DEFAULT 0.5,
    "is_verified" boolean DEFAULT false,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "serving_size_g" numeric DEFAULT 100,
    "serving_name" "text",
    "brand" "text",
    "allergens" "text"[] DEFAULT '{}'::"text"[]
);


ALTER TABLE "public"."foods_custom" OWNER TO "postgres";


COMMENT ON COLUMN "public"."foods_custom"."allergens" IS 'Standard allergens: gluten, dairy, eggs, nuts, peanuts, soy, fish, shellfish, sesame, celery, mustard, sulfites, lupin, molluscs';



CREATE TABLE IF NOT EXISTS "public"."foods_portions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "food_id" "uuid" NOT NULL,
    "name_de" "text" NOT NULL,
    "name_en" "text",
    "amount_g" numeric(8,2) NOT NULL,
    "is_default" boolean DEFAULT false,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "name_th" "text",
    "sort_order" integer DEFAULT 0
);


ALTER TABLE "public"."foods_portions" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."health_markers" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "marker_name" "text" NOT NULL,
    "value" numeric NOT NULL,
    "unit" "text" NOT NULL,
    "date" "date" NOT NULL,
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."health_markers" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."injection_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "substance_name" "text" NOT NULL,
    "dose" numeric NOT NULL,
    "dose_unit" "text" DEFAULT 'mg'::"text" NOT NULL,
    "site" "text" NOT NULL,
    "date" "date" NOT NULL,
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."injection_logs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."intake_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "stack_item_id" "uuid" NOT NULL,
    "date" "date" NOT NULL,
    "status" "text" DEFAULT 'pending'::"text" NOT NULL,
    "taken_at" timestamp with time zone,
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."intake_logs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."intake_schedule" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "stack_item_id" "uuid" NOT NULL,
    "scheduled_time" "text" NOT NULL,
    "with_meal" "text",
    "notes" "text"
);


ALTER TABLE "public"."intake_schedule" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."lab_results" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "lab_date" "date" NOT NULL,
    "lab_name" "text",
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."lab_results" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."lab_values" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "lab_result_id" "uuid" NOT NULL,
    "biomarker_id" "uuid" NOT NULL,
    "value" numeric(12,4) NOT NULL,
    "unit" "text",
    "flag" "text",
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."lab_values" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."macro_cycling_configs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "goal_id" "uuid" NOT NULL,
    "cycling_type" character varying(20) DEFAULT 'none'::character varying,
    "training_protein" numeric(3,1) DEFAULT 2.0,
    "training_fat" numeric(3,1) DEFAULT 0.6,
    "training_carbs_calc" character varying(10) DEFAULT 'rest'::character varying,
    "training_carbs_fixed" integer,
    "training_calories" integer,
    "rest_protein" numeric(3,1) DEFAULT 2.2,
    "rest_fat" numeric(3,1) DEFAULT 1.2,
    "rest_carbs_calc" character varying(10) DEFAULT 'fixed'::character varying,
    "rest_carbs_fixed" integer DEFAULT 120,
    "rest_calories" integer,
    "training_days" integer[] DEFAULT '{1,2,3,4,5}'::integer[],
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."macro_cycling_configs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."marketplace_categories" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "slug" "text" NOT NULL,
    "icon" "text",
    "description" "text",
    "parent_id" "uuid",
    "sort_order" integer DEFAULT 0
);


ALTER TABLE "public"."marketplace_categories" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."marketplace_creators" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "display_name" "text" NOT NULL,
    "bio" "text",
    "avatar_url" "text",
    "specialties" "text"[],
    "verified" boolean DEFAULT false,
    "tier" "text" DEFAULT 'starter'::"text",
    "total_sales" integer DEFAULT 0,
    "total_revenue" numeric(10,2) DEFAULT 0,
    "rating" numeric(3,2) DEFAULT 0,
    "review_count" integer DEFAULT 0,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."marketplace_creators" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."marketplace_products" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "creator_id" "uuid" NOT NULL,
    "type" "text" NOT NULL,
    "title" "text" NOT NULL,
    "description" "text",
    "short_description" "text",
    "cover_image" "text",
    "preview_images" "text"[],
    "pricing_model" "text" DEFAULT 'one_time'::"text",
    "price" numeric(10,2),
    "currency" "text" DEFAULT 'USD'::"text",
    "trial_days" integer DEFAULT 0,
    "difficulty" "text",
    "duration_weeks" integer,
    "equipment" "text"[],
    "goals" "text"[],
    "tags" "text"[],
    "language" "text" DEFAULT 'de'::"text",
    "content" "jsonb" DEFAULT '{}'::"jsonb",
    "bundle_components" "jsonb" DEFAULT '[]'::"jsonb",
    "purchases" integer DEFAULT 0,
    "rating" numeric(3,2) DEFAULT 0,
    "review_count" integer DEFAULT 0,
    "featured" boolean DEFAULT false,
    "status" "text" DEFAULT 'draft'::"text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."marketplace_products" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."marketplace_purchases" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "product_id" "uuid" NOT NULL,
    "price_paid" numeric(10,2) DEFAULT 0,
    "currency" "text" DEFAULT 'USD'::"text",
    "status" "text" DEFAULT 'active'::"text",
    "activated_at" timestamp with time zone DEFAULT "now"(),
    "expires_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."marketplace_purchases" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."marketplace_reviews" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "product_id" "uuid" NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "rating" integer NOT NULL,
    "title" "text",
    "content" "text",
    "verified_purchase" boolean DEFAULT false,
    "helpful_count" integer DEFAULT 0,
    "created_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "marketplace_reviews_rating_check" CHECK ((("rating" >= 1) AND ("rating" <= 5)))
);


ALTER TABLE "public"."marketplace_reviews" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."meal_plan_days" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "plan_id" "uuid" NOT NULL,
    "day_number" integer NOT NULL,
    "name" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."meal_plan_days" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."meal_plan_items" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "day_id" "uuid" NOT NULL,
    "meal_type" "text" NOT NULL,
    "food_id" "uuid",
    "custom_food_id" "uuid",
    "recipe_id" "uuid",
    "name" "text" NOT NULL,
    "amount_g" numeric DEFAULT 100 NOT NULL,
    "calories_kcal" numeric,
    "protein_g" numeric,
    "carbs_g" numeric,
    "fat_g" numeric,
    "sort_order" integer DEFAULT 0,
    "created_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "meal_plan_items_meal_type_check" CHECK (("meal_type" = ANY (ARRAY['breakfast'::"text", 'lunch'::"text", 'dinner'::"text", 'snack'::"text"])))
);


ALTER TABLE "public"."meal_plan_items" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."meal_plans" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "name" "text" NOT NULL,
    "description" "text",
    "target_calories" numeric,
    "target_protein_g" numeric,
    "target_carbs_g" numeric,
    "target_fat_g" numeric,
    "days_count" integer DEFAULT 7,
    "is_active" boolean DEFAULT false,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "source" "text" DEFAULT 'user'::"text",
    "source_template_id" "uuid",
    "coach_locked" boolean DEFAULT false,
    CONSTRAINT "meal_plans_source_check" CHECK (("source" = ANY (ARRAY['user'::"text", 'coach'::"text", 'marketplace'::"text"])))
);


ALTER TABLE "public"."meal_plans" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."medication_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "medication_id" "uuid" NOT NULL,
    "taken_at" timestamp with time zone DEFAULT "now"(),
    "status" "text" DEFAULT 'taken'::"text",
    "notes" "text"
);


ALTER TABLE "public"."medication_logs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."medications" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "name" "text" NOT NULL,
    "dosage" "text",
    "frequency" "text",
    "category" "text" DEFAULT 'rx'::"text",
    "purpose" "text",
    "prescriber" "text",
    "start_date" "date",
    "end_date" "date",
    "active" boolean DEFAULT true,
    "reminders" "jsonb" DEFAULT '[]'::"jsonb",
    "side_effects" "text"[],
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."medications" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."mesocycle_weeks" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "mesocycle_id" "uuid",
    "week_number" integer NOT NULL,
    "target_sets_per_muscle" integer,
    "target_rpe_min" numeric(3,1),
    "target_rpe_max" numeric(3,1),
    "is_deload" boolean DEFAULT false,
    "actual_sets" integer,
    "actual_avg_rpe" numeric(3,1),
    "adherence_pct" numeric(5,2),
    "notes" "text"
);


ALTER TABLE "public"."mesocycle_weeks" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."mesocycles" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "plan_id" "uuid",
    "name" "text" NOT NULL,
    "mesocycle_type" "text" NOT NULL,
    "weeks" integer DEFAULT 6 NOT NULL,
    "start_date" "date" NOT NULL,
    "end_date" "date" GENERATED ALWAYS AS (("start_date" + ((("weeks" * 7))::double precision * '1 day'::interval))) STORED,
    "volume_strategy" "text" DEFAULT 'linear_ramp'::"text",
    "base_volume" integer DEFAULT 12,
    "peak_volume" integer DEFAULT 20,
    "deload_week" boolean DEFAULT true,
    "weekly_targets" "jsonb" DEFAULT '[]'::"jsonb",
    "status" "text" DEFAULT 'active'::"text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."mesocycles" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."muscle_groups" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "name_de" "text",
    "name_th" "text",
    "body_region" "text" NOT NULL,
    "display_order" integer DEFAULT 0
);


ALTER TABLE "public"."muscle_groups" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."nutrition_micro_flags" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "date" "date" NOT NULL,
    "nutrient" "text" NOT NULL,
    "flag_type" "text" NOT NULL,
    "actual_value" numeric(8,3),
    "target_value" numeric(8,3),
    "percentage" numeric(5,2),
    "severity" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "nutrition_micro_flags_flag_type_check" CHECK (("flag_type" = ANY (ARRAY['deficit'::"text", 'surplus'::"text", 'optimal'::"text"]))),
    CONSTRAINT "nutrition_micro_flags_severity_check" CHECK (("severity" = ANY (ARRAY['info'::"text", 'warn'::"text", 'block'::"text"])))
);


ALTER TABLE "public"."nutrition_micro_flags" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."nutrition_targets" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "user_level" "text" DEFAULT 'intermediate'::"text" NOT NULL,
    "kcal_target" numeric(8,2),
    "protein_g_target" numeric(8,2),
    "carbs_g_target" numeric(8,2),
    "fat_g_target" numeric(8,2),
    "fiber_g_target" numeric(8,2),
    "water_ml_target" numeric(8,2),
    "vitamin_a_ug_target" numeric(8,2) DEFAULT 900,
    "vitamin_d_ug_target" numeric(8,2) DEFAULT 20,
    "vitamin_c_mg_target" numeric(8,2) DEFAULT 90,
    "calcium_mg_target" numeric(8,2) DEFAULT 1000,
    "iron_mg_target" numeric(8,2) DEFAULT 8,
    "magnesium_mg_target" numeric(8,2) DEFAULT 400,
    "zinc_mg_target" numeric(8,2) DEFAULT 11,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "nutrition_targets_user_level_check" CHECK (("user_level" = ANY (ARRAY['beginner'::"text", 'intermediate'::"text", 'advanced'::"text", 'elite'::"text"])))
);


ALTER TABLE "public"."nutrition_targets" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."photo_sessions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "date" "date" DEFAULT CURRENT_DATE NOT NULL,
    "session_type" character varying(20) NOT NULL,
    "photo_count" integer DEFAULT 0,
    "notes" "text",
    "overall_ai_analysis" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."photo_sessions" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."program_assignments" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "program_id" "uuid" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "coach_id" "uuid" NOT NULL,
    "current_week" integer DEFAULT 1,
    "status" "text" DEFAULT 'active'::"text",
    "custom_notes" "text",
    "started_at" timestamp with time zone DEFAULT "now"(),
    "completed_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "program_assignments_status_check" CHECK (("status" = ANY (ARRAY['active'::"text", 'paused'::"text", 'completed'::"text", 'cancelled'::"text"])))
);


ALTER TABLE "public"."program_assignments" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."recipe_items" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "recipe_id" "uuid" NOT NULL,
    "food_id" "uuid",
    "name" "text" NOT NULL,
    "amount_g" numeric DEFAULT 100 NOT NULL,
    "calories_kcal" numeric,
    "protein_g" numeric,
    "carbs_g" numeric,
    "fat_g" numeric,
    "sort_order" integer DEFAULT 0
);


ALTER TABLE "public"."recipe_items" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."recipes" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "name" "text" NOT NULL,
    "description" "text",
    "servings" integer DEFAULT 1 NOT NULL,
    "prep_time_min" integer,
    "cook_time_min" integer,
    "instructions" "text",
    "tags" "text"[] DEFAULT '{}'::"text"[],
    "is_favorite" boolean DEFAULT false,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."recipes" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."recovery_checkins" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "date" "date" DEFAULT CURRENT_DATE NOT NULL,
    "sleep_hours" numeric(3,1),
    "sleep_quality" integer,
    "sleep_time" time without time zone,
    "wake_time" time without time zone,
    "subjective_feeling" integer,
    "mood" "text",
    "soreness" "jsonb" DEFAULT '{}'::"jsonb",
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "recovery_checkins_mood_check" CHECK (("mood" = ANY (ARRAY['motivated'::"text", 'good'::"text", 'neutral'::"text", 'tired'::"text", 'sick'::"text"]))),
    CONSTRAINT "recovery_checkins_sleep_quality_check" CHECK ((("sleep_quality" >= 1) AND ("sleep_quality" <= 10))),
    CONSTRAINT "recovery_checkins_subjective_feeling_check" CHECK ((("subjective_feeling" >= 1) AND ("subjective_feeling" <= 10)))
);


ALTER TABLE "public"."recovery_checkins" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."recovery_modalities" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "date" "date" DEFAULT CURRENT_DATE NOT NULL,
    "modality" "text" NOT NULL,
    "duration_min" integer,
    "temperature_c" numeric(4,1),
    "subtype" "text",
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "recovery_modalities_modality_check" CHECK (("modality" = ANY (ARRAY['cold_plunge'::"text", 'sauna'::"text", 'massage'::"text", 'stretching'::"text", 'breathwork'::"text", 'meditation'::"text", 'nap'::"text", 'active_recovery'::"text"])))
);


ALTER TABLE "public"."recovery_modalities" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."recovery_scores" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "date" "date" DEFAULT CURRENT_DATE NOT NULL,
    "score" integer,
    "sleep_component" numeric(5,2),
    "feeling_component" numeric(5,2),
    "soreness_component" numeric(5,2),
    "training_component" numeric(5,2),
    "nutrition_component" numeric(5,2),
    "mood_component" numeric(5,2),
    "modality_bonus" numeric(5,2) DEFAULT 0,
    "muscle_recovery" "jsonb" DEFAULT '{}'::"jsonb",
    "overtraining_signals" integer DEFAULT 0,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "recovery_scores_score_check" CHECK ((("score" >= 0) AND ("score" <= 100)))
);


ALTER TABLE "public"."recovery_scores" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."refeed_schedules" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "goal_id" "uuid" NOT NULL,
    "frequency" character varying(20) DEFAULT 'none'::character varying,
    "refeed_day_of_week" integer DEFAULT 6,
    "refeed_calories" integer,
    "refeed_protein" integer,
    "refeed_carbs" integer,
    "refeed_fat" integer,
    "deficit_calories" integer,
    "deficit_protein" integer,
    "deficit_carbs" integer,
    "deficit_fat" integer,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."refeed_schedules" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."routine_exercises" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "routine_id" "uuid" NOT NULL,
    "exercise_id" "uuid" NOT NULL,
    "sort_order" integer DEFAULT 0 NOT NULL,
    "target_sets" integer DEFAULT 3 NOT NULL,
    "target_reps" integer DEFAULT 10 NOT NULL,
    "target_weight" numeric(6,2),
    "target_rpe" numeric(3,1),
    "target_rir" integer,
    "rest_time_seconds" integer DEFAULT 90,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."routine_exercises" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."routines" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "name" "text" NOT NULL,
    "description" "text",
    "days_per_week" integer,
    "progression_model" "text" DEFAULT 'linear'::"text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."routines" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."stack_items" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "stack_id" "uuid" NOT NULL,
    "supplement_id" "uuid",
    "custom_name" "text",
    "dose" numeric NOT NULL,
    "dose_unit" "text" NOT NULL,
    "frequency" "text" DEFAULT 'daily'::"text",
    "timing" "text",
    "cycling" "jsonb",
    "notes" "text",
    "cost_per_month" numeric,
    "sort_order" integer DEFAULT 0,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."stack_items" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."supplement_interactions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "supplement1_id" "uuid",
    "supplement1_name" "text",
    "supplement2_id" "uuid",
    "supplement2_name" "text",
    "interaction_type" "text" NOT NULL,
    "severity" "text" DEFAULT 'info'::"text" NOT NULL,
    "reason" "text" NOT NULL,
    "reason_de" "text",
    "reason_en" "text",
    "reason_th" "text",
    "source" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."supplement_interactions" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."supplements" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "name_de" "text",
    "name_en" "text",
    "name_th" "text",
    "brand" "text",
    "category" "text" NOT NULL,
    "form" "text",
    "serving_size" numeric,
    "serving_unit" "text",
    "ingredients" "jsonb",
    "evidence_grade" character(1),
    "evidence_data" "jsonb",
    "timing_default" "text",
    "absorption_notes" "jsonb",
    "cost_per_serving" numeric,
    "is_curated" boolean DEFAULT true,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."supplements" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."symptom_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "symptom_type_id" "uuid" NOT NULL,
    "log_date" "date" DEFAULT CURRENT_DATE NOT NULL,
    "severity" integer NOT NULL,
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "symptom_logs_severity_check" CHECK ((("severity" >= 0) AND ("severity" <= 10)))
);


ALTER TABLE "public"."symptom_logs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."symptom_types" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "name_de" "text" NOT NULL,
    "category" "text" NOT NULL,
    "icon" "text",
    "sort_order" integer DEFAULT 0
);


ALTER TABLE "public"."symptom_types" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."tdee_history" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "date" "date" NOT NULL,
    "tdee_estimate" integer,
    "avg_intake" integer,
    "avg_weight_kg" numeric(5,2),
    "weight_change_kg" numeric(4,2),
    "data_points" integer,
    "confidence" character varying(10) DEFAULT 'low'::character varying,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."tdee_history" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."training_plan_days" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "plan_id" "uuid" NOT NULL,
    "day_of_week" integer,
    "sequence_order" integer,
    "routine_id" "uuid" NOT NULL,
    "label" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."training_plan_days" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."training_plans" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "name" "text" DEFAULT 'My Plan'::"text" NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "rotation_type" "text" DEFAULT 'weekly'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."training_plans" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."user_food_preferences" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "diet_type" "text" DEFAULT 'omnivore'::"text",
    "allergies" "text"[] DEFAULT '{}'::"text"[],
    "intolerances" "text"[] DEFAULT '{}'::"text"[],
    "liked_foods" "jsonb" DEFAULT '[]'::"jsonb",
    "disliked_foods" "jsonb" DEFAULT '[]'::"jsonb",
    "preferred_cuisines" "text"[] DEFAULT '{}'::"text"[],
    "avoided_cuisines" "text"[] DEFAULT '{}'::"text"[],
    "meals_per_day" integer DEFAULT 4,
    "snacks_per_day" integer DEFAULT 1,
    "cooking_skill" "text" DEFAULT 'intermediate'::"text",
    "prep_time_max" integer DEFAULT 30,
    "meal_prep_ok" boolean DEFAULT true,
    "budget_level" "text" DEFAULT 'medium'::"text",
    "high_protein_foods" "text"[] DEFAULT '{}'::"text"[],
    "preferred_carb_sources" "text"[] DEFAULT '{}'::"text"[],
    "preferred_fat_sources" "text"[] DEFAULT '{}'::"text"[],
    "notes" "text" DEFAULT ''::"text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "user_food_preferences_budget_level_check" CHECK (("budget_level" = ANY (ARRAY['low'::"text", 'medium'::"text", 'high'::"text", 'no_limit'::"text"]))),
    CONSTRAINT "user_food_preferences_cooking_skill_check" CHECK (("cooking_skill" = ANY (ARRAY['beginner'::"text", 'intermediate'::"text", 'advanced'::"text"]))),
    CONSTRAINT "user_food_preferences_diet_type_check" CHECK (("diet_type" = ANY (ARRAY['omnivore'::"text", 'pescatarian'::"text", 'vegetarian'::"text", 'vegan'::"text", 'keto'::"text", 'paleo'::"text", 'mediterranean'::"text", 'carnivore'::"text", 'custom'::"text"])))
);


ALTER TABLE "public"."user_food_preferences" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."user_inventory" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "stack_item_id" "uuid",
    "supplement_name" "text",
    "quantity_remaining" numeric,
    "quantity_unit" "text",
    "servings_per_container" numeric,
    "purchase_date" "date",
    "expiry_date" "date",
    "cost" numeric,
    "low_stock_threshold" numeric DEFAULT 7,
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."user_inventory" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."user_nutrition_goals" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "goal_type" character varying(20) DEFAULT 'maintain'::character varying NOT NULL,
    "goal_type_new" character varying(40),
    "tdee_calculated" integer,
    "tdee_manual_override" integer,
    "tdee_modifier" numeric(4,2) DEFAULT 0,
    "tdee_last_updated" timestamp with time zone,
    "calorie_target" integer,
    "protein_target" integer,
    "carbs_target" integer,
    "fat_target" integer,
    "fiber_target" integer DEFAULT 30,
    "protein_per_kg" numeric(3,1) DEFAULT 2.0,
    "macro_preset" character varying(20) DEFAULT 'balanced'::character varying,
    "weekly_rate" numeric(3,2) DEFAULT 0.5,
    "weight_change_target_percent" numeric(4,2),
    "max_duration_weeks" integer,
    "started_at" timestamp with time zone,
    "is_active" boolean DEFAULT true,
    "status" character varying(10) DEFAULT 'active'::character varying,
    "current_weight_kg" numeric(5,1),
    "height_cm" numeric(5,1),
    "age" integer,
    "gender" character varying(10),
    "activity_level" character varying(25) DEFAULT 'moderately_active'::character varying,
    "training_days_per_week" integer DEFAULT 4,
    "training_type" character varying(10) DEFAULT 'strength'::character varying,
    "onboarding_completed" boolean DEFAULT false,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."user_nutrition_goals" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."user_profiles" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "gender" "text",
    "birth_date" "date",
    "height_cm" numeric,
    "weight_kg" numeric,
    "body_fat_pct" numeric,
    "experience_level" "text",
    "training_frequency" integer,
    "training_duration" integer,
    "primary_goal" "text",
    "dietary_preference" "text",
    "allergies" "text"[] DEFAULT '{}'::"text"[],
    "unit_system" "text" DEFAULT 'metric'::"text",
    "equipment_access" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."user_profiles" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."user_settings" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "setting_key" "text" NOT NULL,
    "setting_value" "jsonb" NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."user_settings" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."user_stacks" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "description" "text",
    "is_active" boolean DEFAULT false,
    "goal" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."user_stacks" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."users" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "email" "text" NOT NULL,
    "password_hash" "text" NOT NULL,
    "display_name" "text",
    "locale" "text" DEFAULT 'en'::"text",
    "role" "text" DEFAULT 'user'::"text",
    "avatar_url" "text",
    "timezone" "text",
    "onboarding_completed" boolean DEFAULT false,
    "onboarding_step" integer DEFAULT 0,
    "is_active" boolean DEFAULT true,
    "email_verified" boolean DEFAULT false,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "users_role_check" CHECK (("role" = ANY (ARRAY['user'::"text", 'coach'::"text", 'admin'::"text"])))
);


ALTER TABLE "public"."users" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."watcher_alerts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "alert_type" "text" NOT NULL,
    "priority" "text" DEFAULT 'medium'::"text" NOT NULL,
    "title" "text" NOT NULL,
    "body" "text" NOT NULL,
    "icon" "text" DEFAULT '⚠️'::"text",
    "module" "text" NOT NULL,
    "cross_modules" "text"[],
    "data" "jsonb" DEFAULT '{}'::"jsonb",
    "status" "text" DEFAULT 'unread'::"text",
    "action_url" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "read_at" timestamp with time zone,
    "dismissed_at" timestamp with time zone
);


ALTER TABLE "public"."watcher_alerts" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."weight_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "date" "date" NOT NULL,
    "weight_kg" numeric(6,2) NOT NULL,
    "body_fat_pct" numeric(5,2),
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."weight_logs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."workout_exercises" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "session_id" "uuid" NOT NULL,
    "exercise_id" "uuid" NOT NULL,
    "sort_order" integer DEFAULT 0 NOT NULL,
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."workout_exercises" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."workout_sessions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" DEFAULT '00000000-0000-0000-0000-000000000001'::"uuid" NOT NULL,
    "date" "date" DEFAULT CURRENT_DATE NOT NULL,
    "started_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "ended_at" timestamp with time zone,
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "routine_id" "uuid",
    "plan_id" "uuid",
    "duration_minutes" integer,
    "total_volume_kg" numeric(10,2),
    "total_sets" integer,
    "total_reps" integer,
    "personal_records" "jsonb" DEFAULT '[]'::"jsonb",
    "feedback_pump" "jsonb" DEFAULT '{}'::"jsonb",
    "feedback_soreness" "jsonb" DEFAULT '{}'::"jsonb"
);


ALTER TABLE "public"."workout_sessions" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."workout_sets" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "workout_exercise_id" "uuid" NOT NULL,
    "set_number" integer NOT NULL,
    "weight_kg" numeric(6,2),
    "reps" integer,
    "rpe" numeric(3,1),
    "rir" integer,
    "completed" boolean DEFAULT false,
    "personal_record" boolean DEFAULT false,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."workout_sets" OWNER TO "postgres";


ALTER TABLE ONLY "public"."agent_log"
    ADD CONSTRAINT "agent_log_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."agent_tasks"
    ADD CONSTRAINT "agent_tasks_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."auto_adjust_rules"
    ADD CONSTRAINT "auto_adjust_rules_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."biomarkers"
    ADD CONSTRAINT "biomarkers_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."body_circumferences"
    ADD CONSTRAINT "body_circumferences_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."body_circumferences"
    ADD CONSTRAINT "body_circumferences_user_id_date_key" UNIQUE ("user_id", "date");



ALTER TABLE ONLY "public"."body_goals"
    ADD CONSTRAINT "body_goals_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."body_measurements"
    ADD CONSTRAINT "body_measurements_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."body_measurements"
    ADD CONSTRAINT "body_measurements_user_id_date_key" UNIQUE ("user_id", "date");



ALTER TABLE ONLY "public"."body_photos"
    ADD CONSTRAINT "body_photos_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."checkin_analysis"
    ADD CONSTRAINT "checkin_analysis_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_action_log"
    ADD CONSTRAINT "coach_action_log_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_ai_actions"
    ADD CONSTRAINT "coach_ai_actions_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_ai_automations"
    ADD CONSTRAINT "coach_ai_automations_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_ai_memory"
    ADD CONSTRAINT "coach_ai_memory_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_briefings"
    ADD CONSTRAINT "coach_briefings_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_briefings"
    ADD CONSTRAINT "coach_briefings_user_id_date_briefing_type_key" UNIQUE ("user_id", "date", "briefing_type");



ALTER TABLE ONLY "public"."coach_checkins"
    ADD CONSTRAINT "coach_checkins_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_client_alerts"
    ADD CONSTRAINT "coach_client_alerts_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_client_messages"
    ADD CONSTRAINT "coach_client_messages_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_client_permissions"
    ADD CONSTRAINT "coach_client_permissions_coach_client_id_key" UNIQUE ("coach_client_id");



ALTER TABLE ONLY "public"."coach_client_permissions"
    ADD CONSTRAINT "coach_client_permissions_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_clients"
    ADD CONSTRAINT "coach_clients_coach_id_client_id_key" UNIQUE ("coach_id", "client_id");



ALTER TABLE ONLY "public"."coach_clients"
    ADD CONSTRAINT "coach_clients_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_conversation_summaries"
    ADD CONSTRAINT "coach_conversation_summaries_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_conversations"
    ADD CONSTRAINT "coach_conversations_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_memory"
    ADD CONSTRAINT "coach_memory_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_memory"
    ADD CONSTRAINT "coach_memory_user_id_key_key" UNIQUE ("user_id", "key");



ALTER TABLE ONLY "public"."coach_messages"
    ADD CONSTRAINT "coach_messages_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_pending_actions"
    ADD CONSTRAINT "coach_pending_actions_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_plan_assignments"
    ADD CONSTRAINT "coach_plan_assignments_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_plan_templates"
    ADD CONSTRAINT "coach_plan_templates_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_programs"
    ADD CONSTRAINT "coach_programs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_settings"
    ADD CONSTRAINT "coach_settings_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_settings"
    ADD CONSTRAINT "coach_settings_user_id_key" UNIQUE ("user_id");



ALTER TABLE ONLY "public"."coach_weekly_reports"
    ADD CONSTRAINT "coach_weekly_reports_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."coach_weekly_reports"
    ADD CONSTRAINT "coach_weekly_reports_user_id_week_start_key" UNIQUE ("user_id", "week_start");



ALTER TABLE ONLY "public"."coaches"
    ADD CONSTRAINT "coaches_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."cycle_plans"
    ADD CONSTRAINT "cycle_plans_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."enhanced_substances"
    ADD CONSTRAINT "enhanced_substances_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."equipment"
    ADD CONSTRAINT "equipment_name_key" UNIQUE ("name");



ALTER TABLE ONLY "public"."equipment"
    ADD CONSTRAINT "equipment_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."exercise_muscles"
    ADD CONSTRAINT "exercise_muscles_pkey" PRIMARY KEY ("exercise_id", "muscle_group_id", "role");



ALTER TABLE ONLY "public"."exercise_progression_config"
    ADD CONSTRAINT "exercise_progression_config_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."exercise_progression_config"
    ADD CONSTRAINT "exercise_progression_config_user_id_exercise_id_key" UNIQUE ("user_id", "exercise_id");



ALTER TABLE ONLY "public"."exercises"
    ADD CONSTRAINT "exercises_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."food_favorites"
    ADD CONSTRAINT "food_favorites_pkey" PRIMARY KEY ("user_id", "food_id");



ALTER TABLE ONLY "public"."foods"
    ADD CONSTRAINT "foods_bls_code_key" UNIQUE ("bls_code");



ALTER TABLE ONLY "public"."foods_custom"
    ADD CONSTRAINT "foods_custom_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."foods"
    ADD CONSTRAINT "foods_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."foods_portions"
    ADD CONSTRAINT "foods_portions_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."health_markers"
    ADD CONSTRAINT "health_markers_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."injection_logs"
    ADD CONSTRAINT "injection_logs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."intake_logs"
    ADD CONSTRAINT "intake_logs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."intake_logs"
    ADD CONSTRAINT "intake_logs_user_id_stack_item_id_date_key" UNIQUE ("user_id", "stack_item_id", "date");



ALTER TABLE ONLY "public"."intake_schedule"
    ADD CONSTRAINT "intake_schedule_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."lab_results"
    ADD CONSTRAINT "lab_results_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."lab_values"
    ADD CONSTRAINT "lab_values_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."macro_cycling_configs"
    ADD CONSTRAINT "macro_cycling_configs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."marketplace_categories"
    ADD CONSTRAINT "marketplace_categories_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."marketplace_categories"
    ADD CONSTRAINT "marketplace_categories_slug_key" UNIQUE ("slug");



ALTER TABLE ONLY "public"."marketplace_creators"
    ADD CONSTRAINT "marketplace_creators_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."marketplace_products"
    ADD CONSTRAINT "marketplace_products_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."marketplace_purchases"
    ADD CONSTRAINT "marketplace_purchases_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."marketplace_reviews"
    ADD CONSTRAINT "marketplace_reviews_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."meal_items"
    ADD CONSTRAINT "meal_items_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."meal_plan_days"
    ADD CONSTRAINT "meal_plan_days_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."meal_plan_days"
    ADD CONSTRAINT "meal_plan_days_plan_id_day_number_key" UNIQUE ("plan_id", "day_number");



ALTER TABLE ONLY "public"."meal_plan_items"
    ADD CONSTRAINT "meal_plan_items_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."meal_plans"
    ADD CONSTRAINT "meal_plans_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."meals"
    ADD CONSTRAINT "meals_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."medication_logs"
    ADD CONSTRAINT "medication_logs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."medications"
    ADD CONSTRAINT "medications_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."mesocycle_weeks"
    ADD CONSTRAINT "mesocycle_weeks_mesocycle_id_week_number_key" UNIQUE ("mesocycle_id", "week_number");



ALTER TABLE ONLY "public"."mesocycle_weeks"
    ADD CONSTRAINT "mesocycle_weeks_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."mesocycles"
    ADD CONSTRAINT "mesocycles_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."muscle_groups"
    ADD CONSTRAINT "muscle_groups_name_key" UNIQUE ("name");



ALTER TABLE ONLY "public"."muscle_groups"
    ADD CONSTRAINT "muscle_groups_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."nutrition_micro_flags"
    ADD CONSTRAINT "nutrition_micro_flags_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."nutrition_targets"
    ADD CONSTRAINT "nutrition_targets_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."nutrition_targets"
    ADD CONSTRAINT "nutrition_targets_user_id_key" UNIQUE ("user_id");



ALTER TABLE ONLY "public"."photo_sessions"
    ADD CONSTRAINT "photo_sessions_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."program_assignments"
    ADD CONSTRAINT "program_assignments_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."recipe_items"
    ADD CONSTRAINT "recipe_items_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."recipes"
    ADD CONSTRAINT "recipes_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."recovery_checkins"
    ADD CONSTRAINT "recovery_checkins_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."recovery_checkins"
    ADD CONSTRAINT "recovery_checkins_user_id_date_key" UNIQUE ("user_id", "date");



ALTER TABLE ONLY "public"."recovery_modalities"
    ADD CONSTRAINT "recovery_modalities_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."recovery_scores"
    ADD CONSTRAINT "recovery_scores_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."recovery_scores"
    ADD CONSTRAINT "recovery_scores_user_id_date_key" UNIQUE ("user_id", "date");



ALTER TABLE ONLY "public"."refeed_schedules"
    ADD CONSTRAINT "refeed_schedules_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."routine_exercises"
    ADD CONSTRAINT "routine_exercises_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."routines"
    ADD CONSTRAINT "routines_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."stack_items"
    ADD CONSTRAINT "stack_items_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."supplement_interactions"
    ADD CONSTRAINT "supplement_interactions_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."supplements"
    ADD CONSTRAINT "supplements_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."symptom_logs"
    ADD CONSTRAINT "symptom_logs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."symptom_types"
    ADD CONSTRAINT "symptom_types_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."tdee_history"
    ADD CONSTRAINT "tdee_history_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."tdee_history"
    ADD CONSTRAINT "tdee_history_user_id_date_key" UNIQUE ("user_id", "date");



ALTER TABLE ONLY "public"."training_plan_days"
    ADD CONSTRAINT "training_plan_days_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."training_plans"
    ADD CONSTRAINT "training_plans_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."user_food_preferences"
    ADD CONSTRAINT "unique_user_prefs" UNIQUE ("user_id");



ALTER TABLE ONLY "public"."user_food_preferences"
    ADD CONSTRAINT "user_food_preferences_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."user_inventory"
    ADD CONSTRAINT "user_inventory_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."user_nutrition_goals"
    ADD CONSTRAINT "user_nutrition_goals_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."user_profiles"
    ADD CONSTRAINT "user_profiles_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."user_profiles"
    ADD CONSTRAINT "user_profiles_user_id_key" UNIQUE ("user_id");



ALTER TABLE ONLY "public"."user_settings"
    ADD CONSTRAINT "user_settings_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."user_settings"
    ADD CONSTRAINT "user_settings_user_id_setting_key_key" UNIQUE ("user_id", "setting_key");



ALTER TABLE ONLY "public"."user_stacks"
    ADD CONSTRAINT "user_stacks_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_email_key" UNIQUE ("email");



ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."watcher_alerts"
    ADD CONSTRAINT "watcher_alerts_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."water_logs"
    ADD CONSTRAINT "water_logs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."weight_logs"
    ADD CONSTRAINT "weight_logs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."workout_exercises"
    ADD CONSTRAINT "workout_exercises_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."workout_sessions"
    ADD CONSTRAINT "workout_sessions_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."workout_sets"
    ADD CONSTRAINT "workout_sets_pkey" PRIMARY KEY ("id");



CREATE INDEX "idx_agent_log_created" ON "public"."agent_log" USING "btree" ("created_at");



CREATE INDEX "idx_agent_log_task" ON "public"."agent_log" USING "btree" ("task_id");



CREATE INDEX "idx_agent_tasks_priority" ON "public"."agent_tasks" USING "btree" ("priority", "created_at");



CREATE INDEX "idx_agent_tasks_status" ON "public"."agent_tasks" USING "btree" ("status");



CREATE INDEX "idx_auto_adjust_goal" ON "public"."auto_adjust_rules" USING "btree" ("goal_id");



CREATE INDEX "idx_body_circumferences_user_date" ON "public"."body_circumferences" USING "btree" ("user_id", "date" DESC);



CREATE INDEX "idx_body_goals_user_status" ON "public"."body_goals" USING "btree" ("user_id", "status");



CREATE INDEX "idx_body_measurements_user_date" ON "public"."body_measurements" USING "btree" ("user_id", "date" DESC);



CREATE INDEX "idx_body_photos_pose" ON "public"."body_photos" USING "btree" ("user_id", "pose_type", "created_at" DESC);



CREATE INDEX "idx_body_photos_session" ON "public"."body_photos" USING "btree" ("session_id");



CREATE INDEX "idx_checkin_analysis_checkin" ON "public"."checkin_analysis" USING "btree" ("checkin_id");



CREATE INDEX "idx_checkin_analysis_client" ON "public"."checkin_analysis" USING "btree" ("client_id", "created_at" DESC);



CREATE INDEX "idx_coach_action_log_user" ON "public"."coach_action_log" USING "btree" ("user_id", "created_at" DESC);



CREATE INDEX "idx_coach_ai_actions_coach" ON "public"."coach_ai_actions" USING "btree" ("coach_id");



CREATE INDEX "idx_coach_ai_automations_coach" ON "public"."coach_ai_automations" USING "btree" ("coach_id");



CREATE INDEX "idx_coach_ai_automations_trigger" ON "public"."coach_ai_automations" USING "btree" ("trigger_type") WHERE ("is_active" = true);



CREATE INDEX "idx_coach_ai_memory_category" ON "public"."coach_ai_memory" USING "btree" ("coach_id", "category");



CREATE INDEX "idx_coach_ai_memory_client" ON "public"."coach_ai_memory" USING "btree" ("client_id") WHERE ("client_id" IS NOT NULL);



CREATE INDEX "idx_coach_ai_memory_coach" ON "public"."coach_ai_memory" USING "btree" ("coach_id");



CREATE UNIQUE INDEX "idx_coach_ai_memory_key" ON "public"."coach_ai_memory" USING "btree" ("coach_id", "key");



CREATE INDEX "idx_coach_alerts_coach" ON "public"."coach_client_alerts" USING "btree" ("coach_id");



CREATE INDEX "idx_coach_alerts_read" ON "public"."coach_client_alerts" USING "btree" ("is_read");



CREATE INDEX "idx_coach_briefings_user_date" ON "public"."coach_briefings" USING "btree" ("user_id", "date");



CREATE INDEX "idx_coach_checkins_client" ON "public"."coach_checkins" USING "btree" ("client_id");



CREATE INDEX "idx_coach_checkins_coach" ON "public"."coach_checkins" USING "btree" ("coach_id");



CREATE INDEX "idx_coach_checkins_status" ON "public"."coach_checkins" USING "btree" ("status");



CREATE INDEX "idx_coach_clients_client" ON "public"."coach_clients" USING "btree" ("client_id");



CREATE INDEX "idx_coach_clients_coach" ON "public"."coach_clients" USING "btree" ("coach_id");



CREATE INDEX "idx_coach_clients_status" ON "public"."coach_clients" USING "btree" ("status");



CREATE INDEX "idx_coach_conv_summaries_user" ON "public"."coach_conversation_summaries" USING "btree" ("user_id");



CREATE INDEX "idx_coach_conversations_user" ON "public"."coach_conversations" USING "btree" ("user_id");



CREATE INDEX "idx_coach_memory_category" ON "public"."coach_memory" USING "btree" ("user_id", "category");



CREATE INDEX "idx_coach_memory_user" ON "public"."coach_memory" USING "btree" ("user_id");



CREATE INDEX "idx_coach_messages_client" ON "public"."coach_client_messages" USING "btree" ("client_id");



CREATE INDEX "idx_coach_messages_coach" ON "public"."coach_client_messages" USING "btree" ("coach_id");



CREATE INDEX "idx_coach_messages_content_search" ON "public"."coach_messages" USING "gin" ("to_tsvector"('"german"'::"regconfig", "content"));



CREATE INDEX "idx_coach_messages_conversation" ON "public"."coach_messages" USING "btree" ("conversation_id");



CREATE INDEX "idx_coach_messages_created" ON "public"."coach_messages" USING "btree" ("created_at");



CREATE INDEX "idx_coach_pending_user" ON "public"."coach_pending_actions" USING "btree" ("user_id", "created_at" DESC);



CREATE INDEX "idx_coach_permissions_client" ON "public"."coach_client_permissions" USING "btree" ("client_id");



CREATE INDEX "idx_coach_permissions_coach" ON "public"."coach_client_permissions" USING "btree" ("coach_id");



CREATE INDEX "idx_coach_permissions_relation" ON "public"."coach_client_permissions" USING "btree" ("coach_client_id");



CREATE INDEX "idx_coach_plan_assignments_client" ON "public"."coach_plan_assignments" USING "btree" ("client_id");



CREATE INDEX "idx_coach_plan_assignments_coach" ON "public"."coach_plan_assignments" USING "btree" ("coach_id");



CREATE INDEX "idx_coach_plan_assignments_status" ON "public"."coach_plan_assignments" USING "btree" ("status") WHERE ("status" = ANY (ARRAY['pending'::"text", 'active'::"text"]));



CREATE INDEX "idx_coach_plan_templates_coach" ON "public"."coach_plan_templates" USING "btree" ("coach_id");



CREATE INDEX "idx_coach_plan_templates_type" ON "public"."coach_plan_templates" USING "btree" ("type");



CREATE INDEX "idx_coach_plan_templates_visibility" ON "public"."coach_plan_templates" USING "btree" ("visibility") WHERE ("visibility" = 'marketplace'::"text");



CREATE INDEX "idx_coach_programs_coach" ON "public"."coach_programs" USING "btree" ("coach_id");



CREATE INDEX "idx_coach_weekly_reports_user" ON "public"."coach_weekly_reports" USING "btree" ("user_id", "week_start");



CREATE INDEX "idx_coaches_user" ON "public"."coaches" USING "btree" ("user_id");



CREATE INDEX "idx_custom_foods_name_de" ON "public"."foods_custom" USING "gin" ("name_de" "public"."gin_trgm_ops");



CREATE INDEX "idx_cycle_plans_user" ON "public"."cycle_plans" USING "btree" ("user_id");



CREATE INDEX "idx_enhanced_substances_category" ON "public"."enhanced_substances" USING "btree" ("category");



CREATE INDEX "idx_exercise_progression_config_user_exercise" ON "public"."exercise_progression_config" USING "btree" ("user_id", "exercise_id");



CREATE INDEX "idx_exercises_name" ON "public"."exercises" USING "gin" ("to_tsvector"('"english"'::"regconfig", "name"));



CREATE INDEX "idx_food_favorites_food" ON "public"."food_favorites" USING "btree" ("food_id");



CREATE INDEX "idx_food_favorites_user" ON "public"."food_favorites" USING "btree" ("user_id");



CREATE INDEX "idx_food_prefs_user" ON "public"."user_food_preferences" USING "btree" ("user_id");



CREATE INDEX "idx_foods_allergens" ON "public"."foods" USING "gin" ("allergens");



CREATE INDEX "idx_foods_bls_code" ON "public"."foods" USING "btree" ("bls_code");



CREATE INDEX "idx_foods_category" ON "public"."foods" USING "btree" ("category");



CREATE INDEX "idx_foods_category_code" ON "public"."foods" USING "btree" ("category_code");



CREATE INDEX "idx_foods_custom_user" ON "public"."foods_custom" USING "btree" ("user_id");



CREATE INDEX "idx_foods_name_de_trgm" ON "public"."foods" USING "gin" ("name_de" "public"."gin_trgm_ops");



CREATE INDEX "idx_foods_nutrients_full" ON "public"."foods" USING "gin" ("nutrients_full");



CREATE INDEX "idx_health_markers_user_date" ON "public"."health_markers" USING "btree" ("user_id", "date");



CREATE INDEX "idx_injection_logs_user_date" ON "public"."injection_logs" USING "btree" ("user_id", "date");



CREATE INDEX "idx_intake_logs_user_date" ON "public"."intake_logs" USING "btree" ("user_id", "date");



CREATE INDEX "idx_intake_schedule_user" ON "public"."intake_schedule" USING "btree" ("user_id");



CREATE INDEX "idx_lab_results_date" ON "public"."lab_results" USING "btree" ("lab_date" DESC);



CREATE INDEX "idx_lab_results_user" ON "public"."lab_results" USING "btree" ("user_id");



CREATE INDEX "idx_lab_values_biomarker" ON "public"."lab_values" USING "btree" ("biomarker_id");



CREATE INDEX "idx_lab_values_result" ON "public"."lab_values" USING "btree" ("lab_result_id");



CREATE INDEX "idx_macro_cycling_goal" ON "public"."macro_cycling_configs" USING "btree" ("goal_id");



CREATE INDEX "idx_meal_items_meal" ON "public"."meal_items" USING "btree" ("meal_id");



CREATE INDEX "idx_meal_plans_active" ON "public"."meal_plans" USING "btree" ("user_id", "is_active") WHERE ("is_active" = true);



CREATE INDEX "idx_meal_plans_user" ON "public"."meal_plans" USING "btree" ("user_id");



CREATE INDEX "idx_meals_user_date" ON "public"."meals" USING "btree" ("user_id", "date");



CREATE INDEX "idx_medication_logs_med" ON "public"."medication_logs" USING "btree" ("medication_id");



CREATE INDEX "idx_medications_user" ON "public"."medications" USING "btree" ("user_id");



CREATE INDEX "idx_micro_flags_user_date" ON "public"."nutrition_micro_flags" USING "btree" ("user_id", "date");



CREATE INDEX "idx_mp_products_creator" ON "public"."marketplace_products" USING "btree" ("creator_id");



CREATE INDEX "idx_mp_products_goals" ON "public"."marketplace_products" USING "gin" ("goals");



CREATE INDEX "idx_mp_products_status" ON "public"."marketplace_products" USING "btree" ("status");



CREATE INDEX "idx_mp_products_type" ON "public"."marketplace_products" USING "btree" ("type");



CREATE INDEX "idx_mp_purchases_user" ON "public"."marketplace_purchases" USING "btree" ("user_id");



CREATE INDEX "idx_mp_reviews_product" ON "public"."marketplace_reviews" USING "btree" ("product_id");



CREATE INDEX "idx_plan_days_plan" ON "public"."meal_plan_days" USING "btree" ("plan_id");



CREATE INDEX "idx_plan_items_day" ON "public"."meal_plan_items" USING "btree" ("day_id");



CREATE INDEX "idx_plan_items_meal_type" ON "public"."meal_plan_items" USING "btree" ("day_id", "meal_type");



CREATE INDEX "idx_portions_default" ON "public"."foods_portions" USING "btree" ("food_id", "is_default") WHERE ("is_default" = true);



CREATE INDEX "idx_portions_food" ON "public"."foods_portions" USING "btree" ("food_id");



CREATE INDEX "idx_portions_food_id" ON "public"."foods_portions" USING "btree" ("food_id");



CREATE INDEX "idx_program_assignments_client" ON "public"."program_assignments" USING "btree" ("client_id");



CREATE INDEX "idx_recipe_items_recipe" ON "public"."recipe_items" USING "btree" ("recipe_id");



CREATE INDEX "idx_recipes_user" ON "public"."recipes" USING "btree" ("user_id");



CREATE INDEX "idx_recovery_checkins_user_date" ON "public"."recovery_checkins" USING "btree" ("user_id", "date");



CREATE INDEX "idx_recovery_modalities_user_date" ON "public"."recovery_modalities" USING "btree" ("user_id", "date");



CREATE INDEX "idx_recovery_scores_user_date" ON "public"."recovery_scores" USING "btree" ("user_id", "date");



CREATE INDEX "idx_refeed_schedule_goal" ON "public"."refeed_schedules" USING "btree" ("goal_id");



CREATE INDEX "idx_routine_exercises_routine_id" ON "public"."routine_exercises" USING "btree" ("routine_id");



CREATE INDEX "idx_routines_user_id" ON "public"."routines" USING "btree" ("user_id");



CREATE INDEX "idx_stack_items_stack" ON "public"."stack_items" USING "btree" ("stack_id");



CREATE INDEX "idx_supplements_category" ON "public"."supplements" USING "btree" ("category");



CREATE INDEX "idx_supplements_name" ON "public"."supplements" USING "gin" ("to_tsvector"('"simple"'::"regconfig", "name"));



CREATE INDEX "idx_symptom_logs_date" ON "public"."symptom_logs" USING "btree" ("log_date");



CREATE INDEX "idx_symptom_logs_user" ON "public"."symptom_logs" USING "btree" ("user_id");



CREATE INDEX "idx_tdee_history_user" ON "public"."tdee_history" USING "btree" ("user_id", "date" DESC);



CREATE INDEX "idx_training_plan_days_plan" ON "public"."training_plan_days" USING "btree" ("plan_id");



CREATE INDEX "idx_training_plans_user" ON "public"."training_plans" USING "btree" ("user_id");



CREATE INDEX "idx_user_nutrition_goals_active" ON "public"."user_nutrition_goals" USING "btree" ("user_id") WHERE ("is_active" = true);



CREATE INDEX "idx_user_nutrition_goals_user" ON "public"."user_nutrition_goals" USING "btree" ("user_id", "is_active");



CREATE INDEX "idx_user_profiles_user" ON "public"."user_profiles" USING "btree" ("user_id");



CREATE INDEX "idx_user_stacks_user" ON "public"."user_stacks" USING "btree" ("user_id");



CREATE INDEX "idx_users_email" ON "public"."users" USING "btree" ("email");



CREATE INDEX "idx_watcher_alerts_created" ON "public"."watcher_alerts" USING "btree" ("created_at" DESC);



CREATE INDEX "idx_watcher_alerts_status" ON "public"."watcher_alerts" USING "btree" ("status");



CREATE INDEX "idx_watcher_alerts_user" ON "public"."watcher_alerts" USING "btree" ("user_id");



CREATE INDEX "idx_water_user_date" ON "public"."water_logs" USING "btree" ("user_id", "date");



CREATE INDEX "idx_weight_user_date" ON "public"."weight_logs" USING "btree" ("user_id", "date");



CREATE INDEX "idx_workout_exercises_session_id" ON "public"."workout_exercises" USING "btree" ("session_id");



CREATE INDEX "idx_workout_sessions_date" ON "public"."workout_sessions" USING "btree" ("date");



CREATE INDEX "idx_workout_sessions_routine" ON "public"."workout_sessions" USING "btree" ("routine_id");



CREATE INDEX "idx_workout_sessions_user_id_date" ON "public"."workout_sessions" USING "btree" ("user_id", "date" DESC);



CREATE INDEX "idx_workout_sets_workout_exercise_id" ON "public"."workout_sets" USING "btree" ("workout_exercise_id");



CREATE INDEX "mesocycle_weeks_mesocycle_id_idx" ON "public"."mesocycle_weeks" USING "btree" ("mesocycle_id");



CREATE INDEX "mesocycles_status_idx" ON "public"."mesocycles" USING "btree" ("status");



CREATE INDEX "mesocycles_user_id_idx" ON "public"."mesocycles" USING "btree" ("user_id");



CREATE OR REPLACE TRIGGER "update_foods_updated_at" BEFORE UPDATE ON "public"."foods" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at_column"();



ALTER TABLE ONLY "public"."agent_log"
    ADD CONSTRAINT "agent_log_task_id_fkey" FOREIGN KEY ("task_id") REFERENCES "public"."agent_tasks"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."auto_adjust_rules"
    ADD CONSTRAINT "auto_adjust_rules_goal_id_fkey" FOREIGN KEY ("goal_id") REFERENCES "public"."user_nutrition_goals"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."body_photos"
    ADD CONSTRAINT "body_photos_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "public"."photo_sessions"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."checkin_analysis"
    ADD CONSTRAINT "checkin_analysis_checkin_id_fkey" FOREIGN KEY ("checkin_id") REFERENCES "public"."coach_checkins"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."coach_ai_actions"
    ADD CONSTRAINT "coach_ai_actions_coach_id_fkey" FOREIGN KEY ("coach_id") REFERENCES "public"."coaches"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."coach_ai_automations"
    ADD CONSTRAINT "coach_ai_automations_coach_id_fkey" FOREIGN KEY ("coach_id") REFERENCES "public"."coaches"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."coach_ai_memory"
    ADD CONSTRAINT "coach_ai_memory_coach_id_fkey" FOREIGN KEY ("coach_id") REFERENCES "public"."coaches"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."coach_checkins"
    ADD CONSTRAINT "coach_checkins_coach_id_fkey" FOREIGN KEY ("coach_id") REFERENCES "public"."coaches"("id");



ALTER TABLE ONLY "public"."coach_client_alerts"
    ADD CONSTRAINT "coach_client_alerts_coach_id_fkey" FOREIGN KEY ("coach_id") REFERENCES "public"."coaches"("id");



ALTER TABLE ONLY "public"."coach_client_messages"
    ADD CONSTRAINT "coach_client_messages_coach_id_fkey" FOREIGN KEY ("coach_id") REFERENCES "public"."coaches"("id");



ALTER TABLE ONLY "public"."coach_client_permissions"
    ADD CONSTRAINT "coach_client_permissions_coach_client_id_fkey" FOREIGN KEY ("coach_client_id") REFERENCES "public"."coach_clients"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."coach_clients"
    ADD CONSTRAINT "coach_clients_coach_id_fkey" FOREIGN KEY ("coach_id") REFERENCES "public"."coaches"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."coach_conversation_summaries"
    ADD CONSTRAINT "coach_conversation_summaries_conversation_id_fkey" FOREIGN KEY ("conversation_id") REFERENCES "public"."coach_conversations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."coach_messages"
    ADD CONSTRAINT "coach_messages_conversation_id_fkey" FOREIGN KEY ("conversation_id") REFERENCES "public"."coach_conversations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."coach_plan_assignments"
    ADD CONSTRAINT "coach_plan_assignments_coach_id_fkey" FOREIGN KEY ("coach_id") REFERENCES "public"."coaches"("id");



ALTER TABLE ONLY "public"."coach_plan_assignments"
    ADD CONSTRAINT "coach_plan_assignments_template_id_fkey" FOREIGN KEY ("template_id") REFERENCES "public"."coach_plan_templates"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."coach_plan_templates"
    ADD CONSTRAINT "coach_plan_templates_coach_id_fkey" FOREIGN KEY ("coach_id") REFERENCES "public"."coaches"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."coach_programs"
    ADD CONSTRAINT "coach_programs_coach_id_fkey" FOREIGN KEY ("coach_id") REFERENCES "public"."coaches"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."exercise_muscles"
    ADD CONSTRAINT "exercise_muscles_exercise_id_fkey" FOREIGN KEY ("exercise_id") REFERENCES "public"."exercises"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."exercise_muscles"
    ADD CONSTRAINT "exercise_muscles_muscle_group_id_fkey" FOREIGN KEY ("muscle_group_id") REFERENCES "public"."muscle_groups"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."exercise_progression_config"
    ADD CONSTRAINT "exercise_progression_config_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id");



ALTER TABLE ONLY "public"."exercises"
    ADD CONSTRAINT "exercises_equipment_id_fkey" FOREIGN KEY ("equipment_id") REFERENCES "public"."equipment"("id");



ALTER TABLE ONLY "public"."food_favorites"
    ADD CONSTRAINT "food_favorites_food_id_fkey" FOREIGN KEY ("food_id") REFERENCES "public"."foods"("id");



ALTER TABLE ONLY "public"."foods_portions"
    ADD CONSTRAINT "foods_portions_food_id_fkey" FOREIGN KEY ("food_id") REFERENCES "public"."foods"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."intake_logs"
    ADD CONSTRAINT "intake_logs_stack_item_id_fkey" FOREIGN KEY ("stack_item_id") REFERENCES "public"."stack_items"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."intake_schedule"
    ADD CONSTRAINT "intake_schedule_stack_item_id_fkey" FOREIGN KEY ("stack_item_id") REFERENCES "public"."stack_items"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."lab_values"
    ADD CONSTRAINT "lab_values_biomarker_id_fkey" FOREIGN KEY ("biomarker_id") REFERENCES "public"."biomarkers"("id");



ALTER TABLE ONLY "public"."lab_values"
    ADD CONSTRAINT "lab_values_lab_result_id_fkey" FOREIGN KEY ("lab_result_id") REFERENCES "public"."lab_results"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."macro_cycling_configs"
    ADD CONSTRAINT "macro_cycling_configs_goal_id_fkey" FOREIGN KEY ("goal_id") REFERENCES "public"."user_nutrition_goals"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."marketplace_categories"
    ADD CONSTRAINT "marketplace_categories_parent_id_fkey" FOREIGN KEY ("parent_id") REFERENCES "public"."marketplace_categories"("id");



ALTER TABLE ONLY "public"."marketplace_products"
    ADD CONSTRAINT "marketplace_products_creator_id_fkey" FOREIGN KEY ("creator_id") REFERENCES "public"."marketplace_creators"("id");



ALTER TABLE ONLY "public"."marketplace_purchases"
    ADD CONSTRAINT "marketplace_purchases_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "public"."marketplace_products"("id");



ALTER TABLE ONLY "public"."marketplace_reviews"
    ADD CONSTRAINT "marketplace_reviews_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "public"."marketplace_products"("id");



ALTER TABLE ONLY "public"."meal_items"
    ADD CONSTRAINT "meal_items_meal_id_fkey" FOREIGN KEY ("meal_id") REFERENCES "public"."meals"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."meal_plan_days"
    ADD CONSTRAINT "meal_plan_days_plan_id_fkey" FOREIGN KEY ("plan_id") REFERENCES "public"."meal_plans"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."meal_plan_items"
    ADD CONSTRAINT "meal_plan_items_custom_food_id_fkey" FOREIGN KEY ("custom_food_id") REFERENCES "public"."foods_custom"("id");



ALTER TABLE ONLY "public"."meal_plan_items"
    ADD CONSTRAINT "meal_plan_items_day_id_fkey" FOREIGN KEY ("day_id") REFERENCES "public"."meal_plan_days"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."meal_plan_items"
    ADD CONSTRAINT "meal_plan_items_food_id_fkey" FOREIGN KEY ("food_id") REFERENCES "public"."foods"("id");



ALTER TABLE ONLY "public"."meal_plan_items"
    ADD CONSTRAINT "meal_plan_items_recipe_id_fkey" FOREIGN KEY ("recipe_id") REFERENCES "public"."recipes"("id");



ALTER TABLE ONLY "public"."medication_logs"
    ADD CONSTRAINT "medication_logs_medication_id_fkey" FOREIGN KEY ("medication_id") REFERENCES "public"."medications"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."mesocycle_weeks"
    ADD CONSTRAINT "mesocycle_weeks_mesocycle_id_fkey" FOREIGN KEY ("mesocycle_id") REFERENCES "public"."mesocycles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."mesocycles"
    ADD CONSTRAINT "mesocycles_plan_id_fkey" FOREIGN KEY ("plan_id") REFERENCES "public"."training_plans"("id");



ALTER TABLE ONLY "public"."program_assignments"
    ADD CONSTRAINT "program_assignments_coach_id_fkey" FOREIGN KEY ("coach_id") REFERENCES "public"."coaches"("id");



ALTER TABLE ONLY "public"."program_assignments"
    ADD CONSTRAINT "program_assignments_program_id_fkey" FOREIGN KEY ("program_id") REFERENCES "public"."coach_programs"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."recipe_items"
    ADD CONSTRAINT "recipe_items_food_id_fkey" FOREIGN KEY ("food_id") REFERENCES "public"."foods"("id");



ALTER TABLE ONLY "public"."recipe_items"
    ADD CONSTRAINT "recipe_items_recipe_id_fkey" FOREIGN KEY ("recipe_id") REFERENCES "public"."recipes"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."refeed_schedules"
    ADD CONSTRAINT "refeed_schedules_goal_id_fkey" FOREIGN KEY ("goal_id") REFERENCES "public"."user_nutrition_goals"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."routine_exercises"
    ADD CONSTRAINT "routine_exercises_exercise_id_fkey" FOREIGN KEY ("exercise_id") REFERENCES "public"."exercises"("id");



ALTER TABLE ONLY "public"."routine_exercises"
    ADD CONSTRAINT "routine_exercises_routine_id_fkey" FOREIGN KEY ("routine_id") REFERENCES "public"."routines"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."stack_items"
    ADD CONSTRAINT "stack_items_stack_id_fkey" FOREIGN KEY ("stack_id") REFERENCES "public"."user_stacks"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."stack_items"
    ADD CONSTRAINT "stack_items_supplement_id_fkey" FOREIGN KEY ("supplement_id") REFERENCES "public"."supplements"("id");



ALTER TABLE ONLY "public"."supplement_interactions"
    ADD CONSTRAINT "supplement_interactions_supplement1_id_fkey" FOREIGN KEY ("supplement1_id") REFERENCES "public"."supplements"("id");



ALTER TABLE ONLY "public"."supplement_interactions"
    ADD CONSTRAINT "supplement_interactions_supplement2_id_fkey" FOREIGN KEY ("supplement2_id") REFERENCES "public"."supplements"("id");



ALTER TABLE ONLY "public"."symptom_logs"
    ADD CONSTRAINT "symptom_logs_symptom_type_id_fkey" FOREIGN KEY ("symptom_type_id") REFERENCES "public"."symptom_types"("id");



ALTER TABLE ONLY "public"."training_plan_days"
    ADD CONSTRAINT "training_plan_days_plan_id_fkey" FOREIGN KEY ("plan_id") REFERENCES "public"."training_plans"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."training_plan_days"
    ADD CONSTRAINT "training_plan_days_routine_id_fkey" FOREIGN KEY ("routine_id") REFERENCES "public"."routines"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."user_inventory"
    ADD CONSTRAINT "user_inventory_stack_item_id_fkey" FOREIGN KEY ("stack_item_id") REFERENCES "public"."stack_items"("id");



ALTER TABLE ONLY "public"."user_profiles"
    ADD CONSTRAINT "user_profiles_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."workout_exercises"
    ADD CONSTRAINT "workout_exercises_exercise_id_fkey" FOREIGN KEY ("exercise_id") REFERENCES "public"."exercises"("id");



ALTER TABLE ONLY "public"."workout_exercises"
    ADD CONSTRAINT "workout_exercises_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "public"."workout_sessions"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."workout_sessions"
    ADD CONSTRAINT "workout_sessions_plan_id_fkey" FOREIGN KEY ("plan_id") REFERENCES "public"."training_plans"("id");



ALTER TABLE ONLY "public"."workout_sessions"
    ADD CONSTRAINT "workout_sessions_routine_id_fkey" FOREIGN KEY ("routine_id") REFERENCES "public"."routines"("id");



ALTER TABLE ONLY "public"."workout_sets"
    ADD CONSTRAINT "workout_sets_workout_exercise_id_fkey" FOREIGN KEY ("workout_exercise_id") REFERENCES "public"."workout_exercises"("id") ON DELETE CASCADE;



CREATE POLICY "Allow SELECT for authenticated users" ON "public"."foods" FOR SELECT TO "authenticated" USING (true);



CREATE POLICY "Allow all for development" ON "public"."body_measurements" USING (true) WITH CHECK (true);



CREATE POLICY "Users manage own permissions" ON "public"."coach_client_permissions" USING ((("client_id" = "auth"."uid"()) OR ("coach_id" = ( SELECT "coaches"."user_id"
   FROM "public"."coaches"
  WHERE ("coaches"."id" = "coach_client_permissions"."coach_id")))));



CREATE POLICY "Users see own custom foods" ON "public"."foods_custom" TO "authenticated" USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users see own meals" ON "public"."meals" TO "authenticated" USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users see own micro flags" ON "public"."nutrition_micro_flags" TO "authenticated" USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users see own targets" ON "public"."nutrition_targets" TO "authenticated" USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users see own water logs" ON "public"."water_logs" TO "authenticated" USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users see own weight logs" ON "public"."weight_logs" TO "authenticated" USING (("auth"."uid"() = "user_id"));



ALTER TABLE "public"."auto_adjust_rules" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."body_circumferences" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."body_goals" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."body_measurements" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."body_photos" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."checkin_analysis" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."coach_ai_actions" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "coach_ai_actions_all" ON "public"."coach_ai_actions" USING (true);



ALTER TABLE "public"."coach_ai_automations" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "coach_ai_automations_all" ON "public"."coach_ai_automations" USING (true);



ALTER TABLE "public"."coach_ai_memory" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "coach_ai_memory_all" ON "public"."coach_ai_memory" USING (true);



CREATE POLICY "coach_alerts_all" ON "public"."coach_client_alerts" USING (true);



ALTER TABLE "public"."coach_briefings" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "coach_briefings_user" ON "public"."coach_briefings" USING (("user_id" = '00000000-0000-0000-0000-000000000001'::"uuid"));



ALTER TABLE "public"."coach_checkins" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "coach_checkins_all" ON "public"."coach_checkins" USING (true);



ALTER TABLE "public"."coach_client_alerts" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."coach_client_messages" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."coach_client_permissions" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."coach_clients" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "coach_clients_all" ON "public"."coach_clients" USING (true);



ALTER TABLE "public"."coach_conversation_summaries" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."coach_conversations" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "coach_conversations_user" ON "public"."coach_conversations" USING (("user_id" = '00000000-0000-0000-0000-000000000001'::"uuid"));



ALTER TABLE "public"."coach_memory" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."coach_messages" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "coach_messages_all" ON "public"."coach_client_messages" USING (true);



CREATE POLICY "coach_messages_user" ON "public"."coach_messages" USING (("user_id" = '00000000-0000-0000-0000-000000000001'::"uuid"));



ALTER TABLE "public"."coach_plan_assignments" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "coach_plan_assignments_all" ON "public"."coach_plan_assignments" USING (true);



ALTER TABLE "public"."coach_plan_templates" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "coach_plan_templates_all" ON "public"."coach_plan_templates" USING (true);



ALTER TABLE "public"."coach_programs" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "coach_programs_all" ON "public"."coach_programs" USING (true);



ALTER TABLE "public"."coach_settings" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "coach_settings_user" ON "public"."coach_settings" USING (("user_id" = '00000000-0000-0000-0000-000000000001'::"uuid"));



ALTER TABLE "public"."coach_weekly_reports" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."coaches" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "coaches_all" ON "public"."coaches" USING (true);



ALTER TABLE "public"."food_favorites" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "food_prefs_all" ON "public"."user_food_preferences" USING (true);



ALTER TABLE "public"."foods" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."foods_custom" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."macro_cycling_configs" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."meal_plan_days" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."meal_plan_items" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."meal_plans" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."meals" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."nutrition_micro_flags" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."nutrition_targets" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."photo_sessions" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."program_assignments" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "program_assignments_all" ON "public"."program_assignments" USING (true);



ALTER TABLE "public"."recipe_items" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."recipes" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."recovery_checkins" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "recovery_checkins_user" ON "public"."recovery_checkins" USING (("user_id" = '00000000-0000-0000-0000-000000000001'::"uuid"));



ALTER TABLE "public"."recovery_modalities" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "recovery_modalities_user" ON "public"."recovery_modalities" USING (("user_id" = '00000000-0000-0000-0000-000000000001'::"uuid"));



ALTER TABLE "public"."recovery_scores" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "recovery_scores_user" ON "public"."recovery_scores" USING (("user_id" = '00000000-0000-0000-0000-000000000001'::"uuid"));



ALTER TABLE "public"."refeed_schedules" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."routines" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "routines_policy" ON "public"."routines" USING (true) WITH CHECK (true);



ALTER TABLE "public"."tdee_history" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."user_food_preferences" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."user_nutrition_goals" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."user_profiles" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "user_profiles_all" ON "public"."user_profiles" USING (true);



ALTER TABLE "public"."users" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "users_all" ON "public"."users" USING (true);



CREATE POLICY "users_own_food_favorites" ON "public"."food_favorites" USING (("user_id" = '00000000-0000-0000-0000-000000000001'::"uuid"));



CREATE POLICY "users_own_plan_days" ON "public"."meal_plan_days" USING (("plan_id" IN ( SELECT "meal_plans"."id"
   FROM "public"."meal_plans"
  WHERE ("meal_plans"."user_id" = '00000000-0000-0000-0000-000000000001'::"uuid"))));



CREATE POLICY "users_own_plan_items" ON "public"."meal_plan_items" USING (("day_id" IN ( SELECT "meal_plan_days"."id"
   FROM "public"."meal_plan_days"
  WHERE ("meal_plan_days"."plan_id" IN ( SELECT "meal_plans"."id"
           FROM "public"."meal_plans"
          WHERE ("meal_plans"."user_id" = '00000000-0000-0000-0000-000000000001'::"uuid"))))));



CREATE POLICY "users_own_plans" ON "public"."meal_plans" USING (("user_id" = '00000000-0000-0000-0000-000000000001'::"uuid"));



CREATE POLICY "users_own_recipe_items" ON "public"."recipe_items" USING (("recipe_id" IN ( SELECT "recipes"."id"
   FROM "public"."recipes"
  WHERE ("recipes"."user_id" = '00000000-0000-0000-0000-000000000001'::"uuid"))));



CREATE POLICY "users_own_recipes" ON "public"."recipes" USING (("user_id" = '00000000-0000-0000-0000-000000000001'::"uuid"));



ALTER TABLE "public"."watcher_alerts" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "watcher_alerts_user" ON "public"."watcher_alerts" USING (("user_id" = '00000000-0000-0000-0000-000000000001'::"uuid"));



ALTER TABLE "public"."water_logs" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."weight_logs" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."workout_sessions" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "workout_sessions_policy" ON "public"."workout_sessions" USING (true) WITH CHECK (true);





ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";


GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";



GRANT ALL ON FUNCTION "public"."gtrgm_in"("cstring") TO "postgres";
GRANT ALL ON FUNCTION "public"."gtrgm_in"("cstring") TO "anon";
GRANT ALL ON FUNCTION "public"."gtrgm_in"("cstring") TO "authenticated";
GRANT ALL ON FUNCTION "public"."gtrgm_in"("cstring") TO "service_role";



GRANT ALL ON FUNCTION "public"."gtrgm_out"("public"."gtrgm") TO "postgres";
GRANT ALL ON FUNCTION "public"."gtrgm_out"("public"."gtrgm") TO "anon";
GRANT ALL ON FUNCTION "public"."gtrgm_out"("public"."gtrgm") TO "authenticated";
GRANT ALL ON FUNCTION "public"."gtrgm_out"("public"."gtrgm") TO "service_role";

























































































































































GRANT ALL ON FUNCTION "public"."gin_extract_query_trgm"("text", "internal", smallint, "internal", "internal", "internal", "internal") TO "postgres";
GRANT ALL ON FUNCTION "public"."gin_extract_query_trgm"("text", "internal", smallint, "internal", "internal", "internal", "internal") TO "anon";
GRANT ALL ON FUNCTION "public"."gin_extract_query_trgm"("text", "internal", smallint, "internal", "internal", "internal", "internal") TO "authenticated";
GRANT ALL ON FUNCTION "public"."gin_extract_query_trgm"("text", "internal", smallint, "internal", "internal", "internal", "internal") TO "service_role";



GRANT ALL ON FUNCTION "public"."gin_extract_value_trgm"("text", "internal") TO "postgres";
GRANT ALL ON FUNCTION "public"."gin_extract_value_trgm"("text", "internal") TO "anon";
GRANT ALL ON FUNCTION "public"."gin_extract_value_trgm"("text", "internal") TO "authenticated";
GRANT ALL ON FUNCTION "public"."gin_extract_value_trgm"("text", "internal") TO "service_role";



GRANT ALL ON FUNCTION "public"."gin_trgm_consistent"("internal", smallint, "text", integer, "internal", "internal", "internal", "internal") TO "postgres";
GRANT ALL ON FUNCTION "public"."gin_trgm_consistent"("internal", smallint, "text", integer, "internal", "internal", "internal", "internal") TO "anon";
GRANT ALL ON FUNCTION "public"."gin_trgm_consistent"("internal", smallint, "text", integer, "internal", "internal", "internal", "internal") TO "authenticated";
GRANT ALL ON FUNCTION "public"."gin_trgm_consistent"("internal", smallint, "text", integer, "internal", "internal", "internal", "internal") TO "service_role";



GRANT ALL ON FUNCTION "public"."gin_trgm_triconsistent"("internal", smallint, "text", integer, "internal", "internal", "internal") TO "postgres";
GRANT ALL ON FUNCTION "public"."gin_trgm_triconsistent"("internal", smallint, "text", integer, "internal", "internal", "internal") TO "anon";
GRANT ALL ON FUNCTION "public"."gin_trgm_triconsistent"("internal", smallint, "text", integer, "internal", "internal", "internal") TO "authenticated";
GRANT ALL ON FUNCTION "public"."gin_trgm_triconsistent"("internal", smallint, "text", integer, "internal", "internal", "internal") TO "service_role";



GRANT ALL ON FUNCTION "public"."gtrgm_compress"("internal") TO "postgres";
GRANT ALL ON FUNCTION "public"."gtrgm_compress"("internal") TO "anon";
GRANT ALL ON FUNCTION "public"."gtrgm_compress"("internal") TO "authenticated";
GRANT ALL ON FUNCTION "public"."gtrgm_compress"("internal") TO "service_role";



GRANT ALL ON FUNCTION "public"."gtrgm_consistent"("internal", "text", smallint, "oid", "internal") TO "postgres";
GRANT ALL ON FUNCTION "public"."gtrgm_consistent"("internal", "text", smallint, "oid", "internal") TO "anon";
GRANT ALL ON FUNCTION "public"."gtrgm_consistent"("internal", "text", smallint, "oid", "internal") TO "authenticated";
GRANT ALL ON FUNCTION "public"."gtrgm_consistent"("internal", "text", smallint, "oid", "internal") TO "service_role";



GRANT ALL ON FUNCTION "public"."gtrgm_decompress"("internal") TO "postgres";
GRANT ALL ON FUNCTION "public"."gtrgm_decompress"("internal") TO "anon";
GRANT ALL ON FUNCTION "public"."gtrgm_decompress"("internal") TO "authenticated";
GRANT ALL ON FUNCTION "public"."gtrgm_decompress"("internal") TO "service_role";



GRANT ALL ON FUNCTION "public"."gtrgm_distance"("internal", "text", smallint, "oid", "internal") TO "postgres";
GRANT ALL ON FUNCTION "public"."gtrgm_distance"("internal", "text", smallint, "oid", "internal") TO "anon";
GRANT ALL ON FUNCTION "public"."gtrgm_distance"("internal", "text", smallint, "oid", "internal") TO "authenticated";
GRANT ALL ON FUNCTION "public"."gtrgm_distance"("internal", "text", smallint, "oid", "internal") TO "service_role";



GRANT ALL ON FUNCTION "public"."gtrgm_options"("internal") TO "postgres";
GRANT ALL ON FUNCTION "public"."gtrgm_options"("internal") TO "anon";
GRANT ALL ON FUNCTION "public"."gtrgm_options"("internal") TO "authenticated";
GRANT ALL ON FUNCTION "public"."gtrgm_options"("internal") TO "service_role";



GRANT ALL ON FUNCTION "public"."gtrgm_penalty"("internal", "internal", "internal") TO "postgres";
GRANT ALL ON FUNCTION "public"."gtrgm_penalty"("internal", "internal", "internal") TO "anon";
GRANT ALL ON FUNCTION "public"."gtrgm_penalty"("internal", "internal", "internal") TO "authenticated";
GRANT ALL ON FUNCTION "public"."gtrgm_penalty"("internal", "internal", "internal") TO "service_role";



GRANT ALL ON FUNCTION "public"."gtrgm_picksplit"("internal", "internal") TO "postgres";
GRANT ALL ON FUNCTION "public"."gtrgm_picksplit"("internal", "internal") TO "anon";
GRANT ALL ON FUNCTION "public"."gtrgm_picksplit"("internal", "internal") TO "authenticated";
GRANT ALL ON FUNCTION "public"."gtrgm_picksplit"("internal", "internal") TO "service_role";



GRANT ALL ON FUNCTION "public"."gtrgm_same"("public"."gtrgm", "public"."gtrgm", "internal") TO "postgres";
GRANT ALL ON FUNCTION "public"."gtrgm_same"("public"."gtrgm", "public"."gtrgm", "internal") TO "anon";
GRANT ALL ON FUNCTION "public"."gtrgm_same"("public"."gtrgm", "public"."gtrgm", "internal") TO "authenticated";
GRANT ALL ON FUNCTION "public"."gtrgm_same"("public"."gtrgm", "public"."gtrgm", "internal") TO "service_role";



GRANT ALL ON FUNCTION "public"."gtrgm_union"("internal", "internal") TO "postgres";
GRANT ALL ON FUNCTION "public"."gtrgm_union"("internal", "internal") TO "anon";
GRANT ALL ON FUNCTION "public"."gtrgm_union"("internal", "internal") TO "authenticated";
GRANT ALL ON FUNCTION "public"."gtrgm_union"("internal", "internal") TO "service_role";



GRANT ALL ON FUNCTION "public"."set_limit"(real) TO "postgres";
GRANT ALL ON FUNCTION "public"."set_limit"(real) TO "anon";
GRANT ALL ON FUNCTION "public"."set_limit"(real) TO "authenticated";
GRANT ALL ON FUNCTION "public"."set_limit"(real) TO "service_role";



GRANT ALL ON FUNCTION "public"."show_limit"() TO "postgres";
GRANT ALL ON FUNCTION "public"."show_limit"() TO "anon";
GRANT ALL ON FUNCTION "public"."show_limit"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."show_limit"() TO "service_role";



GRANT ALL ON FUNCTION "public"."show_trgm"("text") TO "postgres";
GRANT ALL ON FUNCTION "public"."show_trgm"("text") TO "anon";
GRANT ALL ON FUNCTION "public"."show_trgm"("text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."show_trgm"("text") TO "service_role";



GRANT ALL ON FUNCTION "public"."similarity"("text", "text") TO "postgres";
GRANT ALL ON FUNCTION "public"."similarity"("text", "text") TO "anon";
GRANT ALL ON FUNCTION "public"."similarity"("text", "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."similarity"("text", "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."similarity_dist"("text", "text") TO "postgres";
GRANT ALL ON FUNCTION "public"."similarity_dist"("text", "text") TO "anon";
GRANT ALL ON FUNCTION "public"."similarity_dist"("text", "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."similarity_dist"("text", "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."similarity_op"("text", "text") TO "postgres";
GRANT ALL ON FUNCTION "public"."similarity_op"("text", "text") TO "anon";
GRANT ALL ON FUNCTION "public"."similarity_op"("text", "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."similarity_op"("text", "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."strict_word_similarity"("text", "text") TO "postgres";
GRANT ALL ON FUNCTION "public"."strict_word_similarity"("text", "text") TO "anon";
GRANT ALL ON FUNCTION "public"."strict_word_similarity"("text", "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."strict_word_similarity"("text", "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."strict_word_similarity_commutator_op"("text", "text") TO "postgres";
GRANT ALL ON FUNCTION "public"."strict_word_similarity_commutator_op"("text", "text") TO "anon";
GRANT ALL ON FUNCTION "public"."strict_word_similarity_commutator_op"("text", "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."strict_word_similarity_commutator_op"("text", "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."strict_word_similarity_dist_commutator_op"("text", "text") TO "postgres";
GRANT ALL ON FUNCTION "public"."strict_word_similarity_dist_commutator_op"("text", "text") TO "anon";
GRANT ALL ON FUNCTION "public"."strict_word_similarity_dist_commutator_op"("text", "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."strict_word_similarity_dist_commutator_op"("text", "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."strict_word_similarity_dist_op"("text", "text") TO "postgres";
GRANT ALL ON FUNCTION "public"."strict_word_similarity_dist_op"("text", "text") TO "anon";
GRANT ALL ON FUNCTION "public"."strict_word_similarity_dist_op"("text", "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."strict_word_similarity_dist_op"("text", "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."strict_word_similarity_op"("text", "text") TO "postgres";
GRANT ALL ON FUNCTION "public"."strict_word_similarity_op"("text", "text") TO "anon";
GRANT ALL ON FUNCTION "public"."strict_word_similarity_op"("text", "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."strict_word_similarity_op"("text", "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."update_updated_at_column"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_updated_at_column"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_updated_at_column"() TO "service_role";



GRANT ALL ON FUNCTION "public"."word_similarity"("text", "text") TO "postgres";
GRANT ALL ON FUNCTION "public"."word_similarity"("text", "text") TO "anon";
GRANT ALL ON FUNCTION "public"."word_similarity"("text", "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."word_similarity"("text", "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."word_similarity_commutator_op"("text", "text") TO "postgres";
GRANT ALL ON FUNCTION "public"."word_similarity_commutator_op"("text", "text") TO "anon";
GRANT ALL ON FUNCTION "public"."word_similarity_commutator_op"("text", "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."word_similarity_commutator_op"("text", "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."word_similarity_dist_commutator_op"("text", "text") TO "postgres";
GRANT ALL ON FUNCTION "public"."word_similarity_dist_commutator_op"("text", "text") TO "anon";
GRANT ALL ON FUNCTION "public"."word_similarity_dist_commutator_op"("text", "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."word_similarity_dist_commutator_op"("text", "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."word_similarity_dist_op"("text", "text") TO "postgres";
GRANT ALL ON FUNCTION "public"."word_similarity_dist_op"("text", "text") TO "anon";
GRANT ALL ON FUNCTION "public"."word_similarity_dist_op"("text", "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."word_similarity_dist_op"("text", "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."word_similarity_op"("text", "text") TO "postgres";
GRANT ALL ON FUNCTION "public"."word_similarity_op"("text", "text") TO "anon";
GRANT ALL ON FUNCTION "public"."word_similarity_op"("text", "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."word_similarity_op"("text", "text") TO "service_role";


















GRANT ALL ON TABLE "public"."agent_log" TO "anon";
GRANT ALL ON TABLE "public"."agent_log" TO "authenticated";
GRANT ALL ON TABLE "public"."agent_log" TO "service_role";



GRANT ALL ON TABLE "public"."agent_tasks" TO "anon";
GRANT ALL ON TABLE "public"."agent_tasks" TO "authenticated";
GRANT ALL ON TABLE "public"."agent_tasks" TO "service_role";



GRANT ALL ON TABLE "public"."agent_tasks_active" TO "anon";
GRANT ALL ON TABLE "public"."agent_tasks_active" TO "authenticated";
GRANT ALL ON TABLE "public"."agent_tasks_active" TO "service_role";



GRANT ALL ON TABLE "public"."agent_tasks_recent" TO "anon";
GRANT ALL ON TABLE "public"."agent_tasks_recent" TO "authenticated";
GRANT ALL ON TABLE "public"."agent_tasks_recent" TO "service_role";



GRANT ALL ON TABLE "public"."auto_adjust_rules" TO "anon";
GRANT ALL ON TABLE "public"."auto_adjust_rules" TO "authenticated";
GRANT ALL ON TABLE "public"."auto_adjust_rules" TO "service_role";



GRANT ALL ON TABLE "public"."biomarkers" TO "anon";
GRANT ALL ON TABLE "public"."biomarkers" TO "authenticated";
GRANT ALL ON TABLE "public"."biomarkers" TO "service_role";



GRANT ALL ON TABLE "public"."body_circumferences" TO "anon";
GRANT ALL ON TABLE "public"."body_circumferences" TO "authenticated";
GRANT ALL ON TABLE "public"."body_circumferences" TO "service_role";



GRANT ALL ON TABLE "public"."body_goals" TO "anon";
GRANT ALL ON TABLE "public"."body_goals" TO "authenticated";
GRANT ALL ON TABLE "public"."body_goals" TO "service_role";



GRANT ALL ON TABLE "public"."body_measurements" TO "anon";
GRANT ALL ON TABLE "public"."body_measurements" TO "authenticated";
GRANT ALL ON TABLE "public"."body_measurements" TO "service_role";



GRANT ALL ON TABLE "public"."body_photos" TO "anon";
GRANT ALL ON TABLE "public"."body_photos" TO "authenticated";
GRANT ALL ON TABLE "public"."body_photos" TO "service_role";



GRANT ALL ON TABLE "public"."checkin_analysis" TO "anon";
GRANT ALL ON TABLE "public"."checkin_analysis" TO "authenticated";
GRANT ALL ON TABLE "public"."checkin_analysis" TO "service_role";



GRANT ALL ON TABLE "public"."coach_action_log" TO "anon";
GRANT ALL ON TABLE "public"."coach_action_log" TO "authenticated";
GRANT ALL ON TABLE "public"."coach_action_log" TO "service_role";



GRANT ALL ON TABLE "public"."coach_ai_actions" TO "anon";
GRANT ALL ON TABLE "public"."coach_ai_actions" TO "authenticated";
GRANT ALL ON TABLE "public"."coach_ai_actions" TO "service_role";



GRANT ALL ON TABLE "public"."coach_ai_automations" TO "anon";
GRANT ALL ON TABLE "public"."coach_ai_automations" TO "authenticated";
GRANT ALL ON TABLE "public"."coach_ai_automations" TO "service_role";



GRANT ALL ON TABLE "public"."coach_ai_memory" TO "anon";
GRANT ALL ON TABLE "public"."coach_ai_memory" TO "authenticated";
GRANT ALL ON TABLE "public"."coach_ai_memory" TO "service_role";



GRANT ALL ON TABLE "public"."coach_briefings" TO "anon";
GRANT ALL ON TABLE "public"."coach_briefings" TO "authenticated";
GRANT ALL ON TABLE "public"."coach_briefings" TO "service_role";



GRANT ALL ON TABLE "public"."coach_checkins" TO "anon";
GRANT ALL ON TABLE "public"."coach_checkins" TO "authenticated";
GRANT ALL ON TABLE "public"."coach_checkins" TO "service_role";



GRANT ALL ON TABLE "public"."coach_client_alerts" TO "anon";
GRANT ALL ON TABLE "public"."coach_client_alerts" TO "authenticated";
GRANT ALL ON TABLE "public"."coach_client_alerts" TO "service_role";



GRANT ALL ON TABLE "public"."coach_client_messages" TO "anon";
GRANT ALL ON TABLE "public"."coach_client_messages" TO "authenticated";
GRANT ALL ON TABLE "public"."coach_client_messages" TO "service_role";



GRANT ALL ON TABLE "public"."coach_client_permissions" TO "anon";
GRANT ALL ON TABLE "public"."coach_client_permissions" TO "authenticated";
GRANT ALL ON TABLE "public"."coach_client_permissions" TO "service_role";



GRANT ALL ON TABLE "public"."coach_clients" TO "anon";
GRANT ALL ON TABLE "public"."coach_clients" TO "authenticated";
GRANT ALL ON TABLE "public"."coach_clients" TO "service_role";



GRANT ALL ON TABLE "public"."coach_conversation_summaries" TO "anon";
GRANT ALL ON TABLE "public"."coach_conversation_summaries" TO "authenticated";
GRANT ALL ON TABLE "public"."coach_conversation_summaries" TO "service_role";



GRANT ALL ON TABLE "public"."coach_conversations" TO "anon";
GRANT ALL ON TABLE "public"."coach_conversations" TO "authenticated";
GRANT ALL ON TABLE "public"."coach_conversations" TO "service_role";



GRANT ALL ON TABLE "public"."coach_memory" TO "anon";
GRANT ALL ON TABLE "public"."coach_memory" TO "authenticated";
GRANT ALL ON TABLE "public"."coach_memory" TO "service_role";



GRANT ALL ON TABLE "public"."coach_messages" TO "anon";
GRANT ALL ON TABLE "public"."coach_messages" TO "authenticated";
GRANT ALL ON TABLE "public"."coach_messages" TO "service_role";



GRANT ALL ON TABLE "public"."coach_pending_actions" TO "anon";
GRANT ALL ON TABLE "public"."coach_pending_actions" TO "authenticated";
GRANT ALL ON TABLE "public"."coach_pending_actions" TO "service_role";



GRANT ALL ON TABLE "public"."coach_plan_assignments" TO "anon";
GRANT ALL ON TABLE "public"."coach_plan_assignments" TO "authenticated";
GRANT ALL ON TABLE "public"."coach_plan_assignments" TO "service_role";



GRANT ALL ON TABLE "public"."coach_plan_templates" TO "anon";
GRANT ALL ON TABLE "public"."coach_plan_templates" TO "authenticated";
GRANT ALL ON TABLE "public"."coach_plan_templates" TO "service_role";



GRANT ALL ON TABLE "public"."coach_programs" TO "anon";
GRANT ALL ON TABLE "public"."coach_programs" TO "authenticated";
GRANT ALL ON TABLE "public"."coach_programs" TO "service_role";



GRANT ALL ON TABLE "public"."coach_settings" TO "anon";
GRANT ALL ON TABLE "public"."coach_settings" TO "authenticated";
GRANT ALL ON TABLE "public"."coach_settings" TO "service_role";



GRANT ALL ON TABLE "public"."coach_weekly_reports" TO "anon";
GRANT ALL ON TABLE "public"."coach_weekly_reports" TO "authenticated";
GRANT ALL ON TABLE "public"."coach_weekly_reports" TO "service_role";



GRANT ALL ON TABLE "public"."coaches" TO "anon";
GRANT ALL ON TABLE "public"."coaches" TO "authenticated";
GRANT ALL ON TABLE "public"."coaches" TO "service_role";



GRANT ALL ON TABLE "public"."cycle_plans" TO "anon";
GRANT ALL ON TABLE "public"."cycle_plans" TO "authenticated";
GRANT ALL ON TABLE "public"."cycle_plans" TO "service_role";



GRANT ALL ON TABLE "public"."meal_items" TO "anon";
GRANT ALL ON TABLE "public"."meal_items" TO "authenticated";
GRANT ALL ON TABLE "public"."meal_items" TO "service_role";



GRANT ALL ON TABLE "public"."meals" TO "anon";
GRANT ALL ON TABLE "public"."meals" TO "authenticated";
GRANT ALL ON TABLE "public"."meals" TO "service_role";



GRANT ALL ON TABLE "public"."water_logs" TO "anon";
GRANT ALL ON TABLE "public"."water_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."water_logs" TO "service_role";



GRANT ALL ON TABLE "public"."daily_nutrition_summary" TO "anon";
GRANT ALL ON TABLE "public"."daily_nutrition_summary" TO "authenticated";
GRANT ALL ON TABLE "public"."daily_nutrition_summary" TO "service_role";



GRANT ALL ON TABLE "public"."enhanced_substances" TO "anon";
GRANT ALL ON TABLE "public"."enhanced_substances" TO "authenticated";
GRANT ALL ON TABLE "public"."enhanced_substances" TO "service_role";



GRANT ALL ON TABLE "public"."equipment" TO "anon";
GRANT ALL ON TABLE "public"."equipment" TO "authenticated";
GRANT ALL ON TABLE "public"."equipment" TO "service_role";



GRANT ALL ON TABLE "public"."exercise_muscles" TO "anon";
GRANT ALL ON TABLE "public"."exercise_muscles" TO "authenticated";
GRANT ALL ON TABLE "public"."exercise_muscles" TO "service_role";



GRANT ALL ON TABLE "public"."exercise_progression_config" TO "anon";
GRANT ALL ON TABLE "public"."exercise_progression_config" TO "authenticated";
GRANT ALL ON TABLE "public"."exercise_progression_config" TO "service_role";



GRANT ALL ON TABLE "public"."exercises" TO "anon";
GRANT ALL ON TABLE "public"."exercises" TO "authenticated";
GRANT ALL ON TABLE "public"."exercises" TO "service_role";



GRANT ALL ON TABLE "public"."food_favorites" TO "anon";
GRANT ALL ON TABLE "public"."food_favorites" TO "authenticated";
GRANT ALL ON TABLE "public"."food_favorites" TO "service_role";



GRANT ALL ON TABLE "public"."foods" TO "anon";
GRANT ALL ON TABLE "public"."foods" TO "authenticated";
GRANT ALL ON TABLE "public"."foods" TO "service_role";



GRANT ALL ON TABLE "public"."foods_custom" TO "anon";
GRANT ALL ON TABLE "public"."foods_custom" TO "authenticated";
GRANT ALL ON TABLE "public"."foods_custom" TO "service_role";



GRANT ALL ON TABLE "public"."foods_portions" TO "anon";
GRANT ALL ON TABLE "public"."foods_portions" TO "authenticated";
GRANT ALL ON TABLE "public"."foods_portions" TO "service_role";



GRANT ALL ON TABLE "public"."health_markers" TO "anon";
GRANT ALL ON TABLE "public"."health_markers" TO "authenticated";
GRANT ALL ON TABLE "public"."health_markers" TO "service_role";



GRANT ALL ON TABLE "public"."injection_logs" TO "anon";
GRANT ALL ON TABLE "public"."injection_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."injection_logs" TO "service_role";



GRANT ALL ON TABLE "public"."intake_logs" TO "anon";
GRANT ALL ON TABLE "public"."intake_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."intake_logs" TO "service_role";



GRANT ALL ON TABLE "public"."intake_schedule" TO "anon";
GRANT ALL ON TABLE "public"."intake_schedule" TO "authenticated";
GRANT ALL ON TABLE "public"."intake_schedule" TO "service_role";



GRANT ALL ON TABLE "public"."lab_results" TO "anon";
GRANT ALL ON TABLE "public"."lab_results" TO "authenticated";
GRANT ALL ON TABLE "public"."lab_results" TO "service_role";



GRANT ALL ON TABLE "public"."lab_values" TO "anon";
GRANT ALL ON TABLE "public"."lab_values" TO "authenticated";
GRANT ALL ON TABLE "public"."lab_values" TO "service_role";



GRANT ALL ON TABLE "public"."macro_cycling_configs" TO "anon";
GRANT ALL ON TABLE "public"."macro_cycling_configs" TO "authenticated";
GRANT ALL ON TABLE "public"."macro_cycling_configs" TO "service_role";



GRANT ALL ON TABLE "public"."marketplace_categories" TO "anon";
GRANT ALL ON TABLE "public"."marketplace_categories" TO "authenticated";
GRANT ALL ON TABLE "public"."marketplace_categories" TO "service_role";



GRANT ALL ON TABLE "public"."marketplace_creators" TO "anon";
GRANT ALL ON TABLE "public"."marketplace_creators" TO "authenticated";
GRANT ALL ON TABLE "public"."marketplace_creators" TO "service_role";



GRANT ALL ON TABLE "public"."marketplace_products" TO "anon";
GRANT ALL ON TABLE "public"."marketplace_products" TO "authenticated";
GRANT ALL ON TABLE "public"."marketplace_products" TO "service_role";



GRANT ALL ON TABLE "public"."marketplace_purchases" TO "anon";
GRANT ALL ON TABLE "public"."marketplace_purchases" TO "authenticated";
GRANT ALL ON TABLE "public"."marketplace_purchases" TO "service_role";



GRANT ALL ON TABLE "public"."marketplace_reviews" TO "anon";
GRANT ALL ON TABLE "public"."marketplace_reviews" TO "authenticated";
GRANT ALL ON TABLE "public"."marketplace_reviews" TO "service_role";



GRANT ALL ON TABLE "public"."meal_plan_days" TO "anon";
GRANT ALL ON TABLE "public"."meal_plan_days" TO "authenticated";
GRANT ALL ON TABLE "public"."meal_plan_days" TO "service_role";



GRANT ALL ON TABLE "public"."meal_plan_items" TO "anon";
GRANT ALL ON TABLE "public"."meal_plan_items" TO "authenticated";
GRANT ALL ON TABLE "public"."meal_plan_items" TO "service_role";



GRANT ALL ON TABLE "public"."meal_plans" TO "anon";
GRANT ALL ON TABLE "public"."meal_plans" TO "authenticated";
GRANT ALL ON TABLE "public"."meal_plans" TO "service_role";



GRANT ALL ON TABLE "public"."medication_logs" TO "anon";
GRANT ALL ON TABLE "public"."medication_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."medication_logs" TO "service_role";



GRANT ALL ON TABLE "public"."medications" TO "anon";
GRANT ALL ON TABLE "public"."medications" TO "authenticated";
GRANT ALL ON TABLE "public"."medications" TO "service_role";



GRANT ALL ON TABLE "public"."mesocycle_weeks" TO "anon";
GRANT ALL ON TABLE "public"."mesocycle_weeks" TO "authenticated";
GRANT ALL ON TABLE "public"."mesocycle_weeks" TO "service_role";



GRANT ALL ON TABLE "public"."mesocycles" TO "anon";
GRANT ALL ON TABLE "public"."mesocycles" TO "authenticated";
GRANT ALL ON TABLE "public"."mesocycles" TO "service_role";



GRANT ALL ON TABLE "public"."muscle_groups" TO "anon";
GRANT ALL ON TABLE "public"."muscle_groups" TO "authenticated";
GRANT ALL ON TABLE "public"."muscle_groups" TO "service_role";



GRANT ALL ON TABLE "public"."nutrition_micro_flags" TO "anon";
GRANT ALL ON TABLE "public"."nutrition_micro_flags" TO "authenticated";
GRANT ALL ON TABLE "public"."nutrition_micro_flags" TO "service_role";



GRANT ALL ON TABLE "public"."nutrition_targets" TO "anon";
GRANT ALL ON TABLE "public"."nutrition_targets" TO "authenticated";
GRANT ALL ON TABLE "public"."nutrition_targets" TO "service_role";



GRANT ALL ON TABLE "public"."photo_sessions" TO "anon";
GRANT ALL ON TABLE "public"."photo_sessions" TO "authenticated";
GRANT ALL ON TABLE "public"."photo_sessions" TO "service_role";



GRANT ALL ON TABLE "public"."program_assignments" TO "anon";
GRANT ALL ON TABLE "public"."program_assignments" TO "authenticated";
GRANT ALL ON TABLE "public"."program_assignments" TO "service_role";



GRANT ALL ON TABLE "public"."recipe_items" TO "anon";
GRANT ALL ON TABLE "public"."recipe_items" TO "authenticated";
GRANT ALL ON TABLE "public"."recipe_items" TO "service_role";



GRANT ALL ON TABLE "public"."recipes" TO "anon";
GRANT ALL ON TABLE "public"."recipes" TO "authenticated";
GRANT ALL ON TABLE "public"."recipes" TO "service_role";



GRANT ALL ON TABLE "public"."recovery_checkins" TO "anon";
GRANT ALL ON TABLE "public"."recovery_checkins" TO "authenticated";
GRANT ALL ON TABLE "public"."recovery_checkins" TO "service_role";



GRANT ALL ON TABLE "public"."recovery_modalities" TO "anon";
GRANT ALL ON TABLE "public"."recovery_modalities" TO "authenticated";
GRANT ALL ON TABLE "public"."recovery_modalities" TO "service_role";



GRANT ALL ON TABLE "public"."recovery_scores" TO "anon";
GRANT ALL ON TABLE "public"."recovery_scores" TO "authenticated";
GRANT ALL ON TABLE "public"."recovery_scores" TO "service_role";



GRANT ALL ON TABLE "public"."refeed_schedules" TO "anon";
GRANT ALL ON TABLE "public"."refeed_schedules" TO "authenticated";
GRANT ALL ON TABLE "public"."refeed_schedules" TO "service_role";



GRANT ALL ON TABLE "public"."routine_exercises" TO "anon";
GRANT ALL ON TABLE "public"."routine_exercises" TO "authenticated";
GRANT ALL ON TABLE "public"."routine_exercises" TO "service_role";



GRANT ALL ON TABLE "public"."routines" TO "anon";
GRANT ALL ON TABLE "public"."routines" TO "authenticated";
GRANT ALL ON TABLE "public"."routines" TO "service_role";



GRANT ALL ON TABLE "public"."stack_items" TO "anon";
GRANT ALL ON TABLE "public"."stack_items" TO "authenticated";
GRANT ALL ON TABLE "public"."stack_items" TO "service_role";



GRANT ALL ON TABLE "public"."supplement_interactions" TO "anon";
GRANT ALL ON TABLE "public"."supplement_interactions" TO "authenticated";
GRANT ALL ON TABLE "public"."supplement_interactions" TO "service_role";



GRANT ALL ON TABLE "public"."supplements" TO "anon";
GRANT ALL ON TABLE "public"."supplements" TO "authenticated";
GRANT ALL ON TABLE "public"."supplements" TO "service_role";



GRANT ALL ON TABLE "public"."symptom_logs" TO "anon";
GRANT ALL ON TABLE "public"."symptom_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."symptom_logs" TO "service_role";



GRANT ALL ON TABLE "public"."symptom_types" TO "anon";
GRANT ALL ON TABLE "public"."symptom_types" TO "authenticated";
GRANT ALL ON TABLE "public"."symptom_types" TO "service_role";



GRANT ALL ON TABLE "public"."tdee_history" TO "anon";
GRANT ALL ON TABLE "public"."tdee_history" TO "authenticated";
GRANT ALL ON TABLE "public"."tdee_history" TO "service_role";



GRANT ALL ON TABLE "public"."training_plan_days" TO "anon";
GRANT ALL ON TABLE "public"."training_plan_days" TO "authenticated";
GRANT ALL ON TABLE "public"."training_plan_days" TO "service_role";



GRANT ALL ON TABLE "public"."training_plans" TO "anon";
GRANT ALL ON TABLE "public"."training_plans" TO "authenticated";
GRANT ALL ON TABLE "public"."training_plans" TO "service_role";



GRANT ALL ON TABLE "public"."user_food_preferences" TO "anon";
GRANT ALL ON TABLE "public"."user_food_preferences" TO "authenticated";
GRANT ALL ON TABLE "public"."user_food_preferences" TO "service_role";



GRANT ALL ON TABLE "public"."user_inventory" TO "anon";
GRANT ALL ON TABLE "public"."user_inventory" TO "authenticated";
GRANT ALL ON TABLE "public"."user_inventory" TO "service_role";



GRANT ALL ON TABLE "public"."user_nutrition_goals" TO "anon";
GRANT ALL ON TABLE "public"."user_nutrition_goals" TO "authenticated";
GRANT ALL ON TABLE "public"."user_nutrition_goals" TO "service_role";



GRANT ALL ON TABLE "public"."user_profiles" TO "anon";
GRANT ALL ON TABLE "public"."user_profiles" TO "authenticated";
GRANT ALL ON TABLE "public"."user_profiles" TO "service_role";



GRANT ALL ON TABLE "public"."user_settings" TO "anon";
GRANT ALL ON TABLE "public"."user_settings" TO "authenticated";
GRANT ALL ON TABLE "public"."user_settings" TO "service_role";



GRANT ALL ON TABLE "public"."user_stacks" TO "anon";
GRANT ALL ON TABLE "public"."user_stacks" TO "authenticated";
GRANT ALL ON TABLE "public"."user_stacks" TO "service_role";



GRANT ALL ON TABLE "public"."users" TO "anon";
GRANT ALL ON TABLE "public"."users" TO "authenticated";
GRANT ALL ON TABLE "public"."users" TO "service_role";



GRANT ALL ON TABLE "public"."watcher_alerts" TO "anon";
GRANT ALL ON TABLE "public"."watcher_alerts" TO "authenticated";
GRANT ALL ON TABLE "public"."watcher_alerts" TO "service_role";



GRANT ALL ON TABLE "public"."weight_logs" TO "anon";
GRANT ALL ON TABLE "public"."weight_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."weight_logs" TO "service_role";



GRANT ALL ON TABLE "public"."workout_exercises" TO "anon";
GRANT ALL ON TABLE "public"."workout_exercises" TO "authenticated";
GRANT ALL ON TABLE "public"."workout_exercises" TO "service_role";



GRANT ALL ON TABLE "public"."workout_sessions" TO "anon";
GRANT ALL ON TABLE "public"."workout_sessions" TO "authenticated";
GRANT ALL ON TABLE "public"."workout_sessions" TO "service_role";



GRANT ALL ON TABLE "public"."workout_sets" TO "anon";
GRANT ALL ON TABLE "public"."workout_sets" TO "authenticated";
GRANT ALL ON TABLE "public"."workout_sets" TO "service_role";









ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";































